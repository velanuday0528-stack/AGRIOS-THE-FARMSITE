import React from 'react';
import { Hero } from '../components/Hero';
import { CoreConcept } from '../components/CoreConcept';
import { TheFarmThinks } from '../components/TheFarmThinks';
import { ResourceOptimization } from '../components/ResourceOptimization';
import { WhyAgrios } from '../components/WhyAgrios';
import { AiDecisionEngine } from '../components/AiDecisionEngine';
import { FarmerExperience } from '../components/FarmerExperience';
import { WhatIfSimulator } from '../components/WhatIfSimulator';
import { ResilienceScore } from '../components/ResilienceScore';
import { DropletJourney } from '../components/DropletJourney';
import { FarmToMarket } from '../components/FarmToMarket';
import { DashboardPreview } from '../components/DashboardPreview';
import { FooterCta } from '../components/FooterCta';
import { AppView } from '../types';

interface LandingViewProps {
  setCurrentView: (view: AppView) => void;
}

export const LandingView: React.FC<LandingViewProps> = ({ setCurrentView }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative selection:bg-emerald-500/30 selection:text-lime-300">
      {/* 1 & 2. Hero Section & Interactive Hero Panel */}
      <Hero
        setCurrentView={setCurrentView}
        onExploreClick={() => scrollTo('core-concept')}
        onHowItWorksClick={() => scrollTo('decision-engine')}
      />

      {/* 4. AGRIOS Core Concept ("Your Farm. Now With Intelligence.") */}
      <CoreConcept />

      {/* 5. "The Farm Thinks" Predictive Timeline Section */}
      <TheFarmThinks />

      {/* 6. Smart Resource Optimization Farm Map & Zone Inspector */}
      <ResourceOptimization />

      {/* 25. Signature Interactive Droplet Journey ("Where Does Your Farm's Next Litre Go?") */}
      <DropletJourney />

      {/* 10. "What-If" Farm Simulator Mini Digital Twin */}
      <WhatIfSimulator />

      {/* 8. AGRIOS AI Decision Engine */}
      <AiDecisionEngine />

      {/* 7. The "Why AGRIOS?" Counters */}
      <WhyAgrios />

      {/* 11. AGRIOS Farm Resilience Score Gauge */}
      <ResilienceScore />

      {/* 9. Farmer Experience Smartphone Voice Demo */}
      <FarmerExperience />

      {/* 12. Farm-To-Market Journey */}
      <FarmToMarket />

      {/* 13. Realistic Dashboard Preview */}
      <DashboardPreview setCurrentView={setCurrentView} />

      {/* 24. Final Landing Page CTA & Footer */}
      <FooterCta
        setCurrentView={setCurrentView}
        onExploreClick={() => scrollTo('core-concept')}
      />
    </div>
  );
};
