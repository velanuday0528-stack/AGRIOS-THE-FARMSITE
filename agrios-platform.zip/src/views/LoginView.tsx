import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Droplets, 
  ArrowRight, 
  Lock, 
  Mail, 
  Sparkles, 
  ShieldCheck, 
  ArrowLeft,
  Check,
  Eye,
  EyeOff
} from 'lucide-react';
import { AppView } from '../types';

interface LoginViewProps {
  setCurrentView: (view: AppView) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ setCurrentView }) => {
  const [identifier, setIdentifier] = useState('farmer@agrios.ai');
  const [password, setPassword] = useState('••••••••••••');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setCurrentView('dashboard');
    }, 600);
  };

  const handleDemoLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setCurrentView('dashboard');
    }, 400);
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#040A06]">
      {/* Background Cinematic Image with Deep Forest Green Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/login-farm.jpg"
          alt="AGRIOS Smart Farm Hydroponics Facility"
          className="w-full h-full object-cover object-center scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#040A06] via-[#051108]/90 to-[#040A06]/85" />
        <div className="absolute inset-0 bg-tech-grid opacity-30 pointer-events-none" />
      </div>

      {/* Floating Back to Home button */}
      <button
        onClick={() => setCurrentView('landing')}
        className="absolute top-6 left-6 z-20 flex items-center gap-2 px-4 py-2 rounded-xl bg-[#091A10]/80 border border-emerald-500/25 text-xs font-mono text-emerald-300 hover:text-white hover:bg-emerald-950/80 transition-all backdrop-blur-md"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Back to AGRIOS.ai</span>
      </button>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Brand Statement & Value (6 cols) */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-lime-500 flex items-center justify-center p-0.5 shadow-xl shadow-emerald-500/30">
                <div className="w-full h-full bg-[#060F09] rounded-[14px] flex items-center justify-center">
                  <Droplets className="w-6 h-6 text-emerald-400" />
                </div>
              </div>
              <div>
                <span className="font-display font-black text-3xl tracking-wider text-white">
                  AGRIOS
                </span>
                <span className="text-xs font-mono tracking-widest uppercase text-lime-400 font-semibold block -mt-1">
                  Intelligent Platform
                </span>
              </div>
            </div>

            <h1 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
              “Your farm.{' '}
              <span className="text-gradient-emerald block">
                Your data. Your intelligence.”
              </span>
            </h1>

            <p className="text-base text-gray-300 font-light max-w-lg leading-relaxed">
              Log in to synchronize your soil sensors, automate solar pump scheduling, and unlock predictive weather advisories across your acres.
            </p>

            <div className="pt-4 space-y-3 font-mono text-xs text-emerald-400/90">
              <div className="flex items-center gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-lime-400" />
                <span>Zero telemetry lock-in • Works offline via SMS & Voice</span>
              </div>
              <div className="flex items-center gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-lime-400" />
                <span>256-bit encrypted agronomic telemetry protection</span>
              </div>
            </div>
          </div>

          {/* Right Column: Glassmorphism Login Card (6 cols) */}
          <div className="lg:col-span-6 flex justify-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="w-full max-w-md rounded-3xl bg-[#07170E]/85 border-2 border-emerald-500/35 p-7 sm:p-9 backdrop-blur-2xl shadow-2xl relative overflow-hidden"
            >
              {/* Subtle animated data lines behind card */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-lime-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="mb-6">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-lime-950/60 border border-lime-500/30 text-lime-300 text-[11px] font-mono mb-2">
                  <Sparkles className="w-3 h-3 text-lime-400" />
                  Farmer Secure Portal
                </div>
                <h2 className="font-display text-2xl sm:text-3xl font-black text-white">
                  Welcome back.
                </h2>
                <p className="text-xs text-gray-400 mt-1">
                  Continue to your intelligent farm dashboard.
                </p>
              </div>

              {/* Login Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                
                {/* Email / Mobile */}
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-gray-300 block">
                    Email / Mobile Number
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="e.g. 9876543210 or farmer@agrios.ai"
                      className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-lime-400 transition-colors pl-10"
                    />
                    <Mail className="w-4 h-4 text-emerald-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <label className="font-mono text-gray-300">Password</label>
                    <a href="#forgot" className="text-lime-400 hover:text-lime-300 font-mono text-[11px]">
                      Forgot Password?
                    </a>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your security pin"
                      className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-lime-400 transition-colors pl-10 pr-10"
                    />
                    <Lock className="w-4 h-4 text-emerald-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember Me */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setRememberMe(!rememberMe)}
                    className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                      rememberMe
                        ? 'bg-lime-400 border-lime-400 text-black'
                        : 'bg-[#040C07] border-gray-600'
                    }`}
                  >
                    {rememberMe && <Check className="w-3 h-3 stroke-[3]" />}
                  </button>
                  <span className="text-xs text-gray-300">Remember my session on this device</span>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 rounded-xl font-bold text-sm text-gray-950 bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 shadow-xl shadow-emerald-500/25 hover:shadow-lime-400/40 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 mt-2"
                >
                  <span>{isLoading ? 'Verifying Telemetry...' : 'Sign In →'}</span>
                </button>

                {/* Divider */}
                <div className="relative py-2 text-center">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-emerald-500/20" />
                  </div>
                  <span className="relative px-3 bg-[#07170E] text-[10px] font-mono uppercase text-gray-400">
                    OR
                  </span>
                </div>

                {/* Google Sign-in */}
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="w-full py-3 rounded-xl border border-white/10 hover:border-emerald-500/40 text-xs font-semibold text-gray-200 hover:text-white bg-white/5 hover:bg-white/10 transition-all flex items-center justify-center gap-2.5"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.4l3.7 2.9C6.5 7.4 9 5 12 5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.6 14.7c-.2-.7-.4-1.5-.4-2.7 0-1.1.2-2 .4-2.7L1.9 6.4C.7 8.8 0 10.8 0 12s.7 3.2 1.9 5.6l3.7-2.9z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.4-6.4-5.3L1.9 16c1.8 3.8 5.6 7 10.1 7z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </button>

                {/* Demo Instant Bypass Button */}
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="w-full py-2.5 rounded-xl bg-lime-950/40 border border-lime-500/30 text-lime-300 text-xs font-mono font-medium hover:bg-lime-950/70 transition-all flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-lime-400" />
                  <span>One-Click Demo Access (Skip Login)</span>
                </button>

              </form>

              {/* Bottom Registration Link */}
              <div className="mt-6 pt-4 border-t border-emerald-500/15 text-center">
                <span className="text-xs text-gray-400">New to AGRIOS? </span>
                <button
                  onClick={() => setCurrentView('signup')}
                  className="text-xs font-bold text-lime-400 hover:text-lime-300 underline underline-offset-2 ml-1"
                >
                  Create your farm account
                </button>
              </div>

            </motion.div>
          </div>

        </div>
      </div>
    </div>
  );
};
