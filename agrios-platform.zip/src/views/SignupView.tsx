import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Droplets, 
  ArrowRight, 
  ArrowLeft, 
  User, 
  Phone, 
  MapPin, 
  Maximize2, 
  Sprout, 
  Sparkles,
  Zap,
  Globe
} from 'lucide-react';
import { AppView, OnboardingState } from '../types';

interface SignupViewProps {
  setCurrentView: (view: AppView) => void;
  setOnboardingData: React.Dispatch<React.SetStateAction<OnboardingState>>;
}

export const SignupView: React.FC<SignupViewProps> = ({ setCurrentView, setOnboardingData }) => {
  const [formData, setFormData] = useState({
    name: 'Ramesh Patel',
    mobile: '+91 98450 12345',
    location: 'Coimbatore, Tamil Nadu',
    farmSize: '2.4 Acres',
    primaryCrop: 'Tomato (Hybrid)',
    irrigationType: 'Precision Drip & Sprinkler',
    energySource: 'Solar Hybrid (Grid Backup)',
    preferredLanguage: 'Tamil'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOnboardingData((prev) => ({
      ...prev,
      farmerName: formData.name,
      mobile: formData.mobile,
      location: formData.location,
      farmSize: formData.farmSize,
      primaryCrop: formData.primaryCrop,
      irrigationType: formData.irrigationType,
      energySource: formData.energySource,
      language: formData.preferredLanguage,
      step: 1
    }));
    setCurrentView('onboarding');
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#040A06] py-16">
      {/* Background Cinematic Visual */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/hero-farm.jpg"
          alt="Smart Farm Setup"
          className="w-full h-full object-cover object-center opacity-30 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#040A06] via-[#051108]/90 to-[#040A06]" />
        <div className="absolute inset-0 bg-tech-grid opacity-30 pointer-events-none" />
      </div>

      {/* Back button */}
      <button
        onClick={() => setCurrentView('landing')}
        className="absolute top-6 left-6 z-20 flex items-center gap-2 px-4 py-2 rounded-xl bg-[#091A10]/80 border border-emerald-500/25 text-xs font-mono text-emerald-300 hover:text-white hover:bg-emerald-950/80 transition-all backdrop-blur-md"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Back to Home</span>
      </button>

      <div className="relative z-10 max-w-2xl mx-auto px-4 sm:px-6 w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl bg-[#07170E]/90 border-2 border-emerald-500/35 p-6 sm:p-10 backdrop-blur-2xl shadow-2xl relative"
        >
          {/* Header */}
          <div className="text-center space-y-2 mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-lime-950/60 border border-lime-500/30 text-lime-300 text-xs font-mono">
              <Sparkles className="w-3.5 h-3.5 text-lime-400" />
              <span>Step 0: Profile Creation</span>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-black text-white">
              Create Your Farm
            </h1>
            <p className="text-xs sm:text-sm text-gray-400 font-light">
              Register your landholding to deploy AGRIOS autonomous resource optimization.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Grid fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Name */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-emerald-400" />
                  Farmer / Farm Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                />
              </div>

              {/* Mobile */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  Mobile Number
                </label>
                <input
                  type="text"
                  required
                  value={formData.mobile}
                  onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                />
              </div>

              {/* Location */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  Farm Location / District
                </label>
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                />
              </div>

              {/* Farm size */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <Maximize2 className="w-3.5 h-3.5 text-emerald-400" />
                  Farm Size
                </label>
                <input
                  type="text"
                  required
                  value={formData.farmSize}
                  onChange={(e) => setFormData({ ...formData, farmSize: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                />
              </div>

              {/* Primary Crop */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                  Primary Crop
                </label>
                <select
                  value={formData.primaryCrop}
                  onChange={(e) => setFormData({ ...formData, primaryCrop: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                >
                  <option value="Tomato (Hybrid)">Tomato (Hybrid)</option>
                  <option value="Chilli & Peppers">Chilli & Peppers</option>
                  <option value="Paddy / Rice">Paddy / Rice</option>
                  <option value="Organic Vegetables">Organic Vegetables</option>
                  <option value="Cotton">Cotton</option>
                  <option value="Sugarcane">Sugarcane</option>
                </select>
              </div>

              {/* Irrigation type */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                  Irrigation Type
                </label>
                <select
                  value={formData.irrigationType}
                  onChange={(e) => setFormData({ ...formData, irrigationType: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                >
                  <option value="Precision Drip & Sprinkler">Precision Drip & Sprinkler</option>
                  <option value="Subsurface Drip Only">Subsurface Drip Only</option>
                  <option value="Flood / Furrow Basin">Flood / Furrow Basin</option>
                  <option value="Rain Gun & Overhead">Rain Gun & Overhead</option>
                </select>
              </div>

              {/* Energy source */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  Energy Source
                </label>
                <select
                  value={formData.energySource}
                  onChange={(e) => setFormData({ ...formData, energySource: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                >
                  <option value="Solar Hybrid (Grid Backup)">Solar Hybrid (Grid Backup)</option>
                  <option value="Off-Grid Dedicated Solar Pump">Off-Grid Dedicated Solar Pump</option>
                  <option value="Agricultural Grid 3-Phase">Agricultural Grid 3-Phase</option>
                  <option value="Diesel Generator Backup">Diesel Generator Backup</option>
                </select>
              </div>

              {/* Preferred language */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-300 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-lime-400" />
                  Preferred Language
                </label>
                <select
                  value={formData.preferredLanguage}
                  onChange={(e) => setFormData({ ...formData, preferredLanguage: e.target.value })}
                  className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-lime-400"
                >
                  <option value="Tamil">Tamil (தமிழ்)</option>
                  <option value="Hindi">Hindi (हिंदी)</option>
                  <option value="Telugu">Telugu (తెలుగు)</option>
                  <option value="Kannada">Kannada (ಕನ್ನಡ)</option>
                  <option value="Marathi">Marathi (मराठी)</option>
                  <option value="English">English</option>
                </select>
              </div>

            </div>

            {/* Submit Action Button */}
            <div className="pt-4">
              <button
                type="submit"
                className="w-full py-4 rounded-xl font-bold text-sm text-gray-950 bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 shadow-xl shadow-emerald-500/30 hover:shadow-lime-400/50 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2"
              >
                <span>Create My AGRIOS Profile →</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center pt-3">
              <span className="text-xs text-gray-400">Already registered? </span>
              <button
                type="button"
                onClick={() => setCurrentView('login')}
                className="text-xs text-lime-400 font-bold hover:underline"
              >
                Sign in to your farm
              </button>
            </div>

          </form>
        </motion.div>
      </div>
    </div>
  );
};
