import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  Cpu, 
  Droplet, 
  Sun, 
  Sprout, 
  CloudSun, 
  Wheat, 
  Database, 
  TrendingUp, 
  FileText, 
  Settings, 
  LogOut, 
  Bell, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  Zap, 
  Sparkles, 
  ArrowUpRight, 
  Sliders, 
  ShieldCheck,
  Play,
  RotateCcw,
  Menu,
  X
} from 'lucide-react';
import { AppView, OnboardingState } from '../types';
import { INITIAL_ZONES } from '../data/mockData';

interface DashboardViewProps {
  setCurrentView: (view: AppView) => void;
  onboardingData?: OnboardingState;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setCurrentView, onboardingData }) => {
  const [activeTab, setActiveTab] = useState('Overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Recommendations state allows live approval interaction
  const [recommendations, setRecommendations] = useState([
    {
      id: 'rec-1',
      icon: Droplet,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/30',
      title: 'Reduce irrigation by 12%',
      detail: 'Soil tension in Zone A indicates residual water holding capacity. Valve timer adjusted to 18 mins.',
      status: 'pending',
      saving: 'Saves 480 L'
    },
    {
      id: 'rec-2',
      icon: Sun,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      title: 'Use solar surplus at 1:20 PM',
      detail: 'Photovoltaic generation peaks at 8.4 kW. Running primary drip manifold during this window incurs zero grid utility tariff.',
      status: 'pending',
      saving: 'Zero Grid Cost'
    },
    {
      id: 'rec-3',
      icon: CloudSun,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10',
      border: 'border-blue-500/30',
      title: 'Delay irrigation due to rainfall probability',
      detail: 'Doppler satellite radar shows 72% rain probability at 3:00 PM tomorrow. Conserve 1,200 L in main reservoir.',
      status: 'pending',
      saving: '1,200 L Buffered'
    }
  ]);

  const handleApproveRec = (id: string) => {
    setRecommendations((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'approved' } : r))
    );
  };

  const navMenuItems = [
    { label: 'Overview', icon: LayoutDashboard },
    { label: 'Farm Intelligence', icon: Cpu },
    { label: 'Water', icon: Droplet },
    { label: 'Energy', icon: Sun },
    { label: 'Crop Health', icon: Sprout },
    { label: 'Weather', icon: CloudSun },
    { label: 'Harvest', icon: Wheat },
    { label: 'Storage', icon: Database },
    { label: 'Market', icon: TrendingUp },
    { label: 'Reports', icon: FileText },
    { label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#040A06] text-white flex flex-col md:flex-row relative overflow-x-hidden">
      
      {/* Sidebar Navigation */}
      <aside className="hidden md:flex flex-col w-64 bg-[#06120A] border-r border-emerald-500/20 p-5 shrink-0 justify-between">
        <div>
          {/* Brand header */}
          <div
            onClick={() => setCurrentView('landing')}
            className="flex items-center gap-3 cursor-pointer mb-8 group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-lime-500 p-0.5 shadow-md">
              <div className="w-full h-full bg-[#060F09] rounded-[10px] flex items-center justify-center">
                <Droplet className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <span className="font-display font-black text-xl tracking-wider text-white">AGRIOS</span>
              <span className="text-[9px] font-mono tracking-widest uppercase text-lime-400 block -mt-1">
                Farm Console
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {navMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.label;

              return (
                <button
                  key={item.label}
                  onClick={() => setActiveTab(item.label)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-lime-400/20 to-emerald-500/20 text-lime-300 border border-lime-400/40 font-bold shadow-sm'
                      : 'text-gray-400 hover:text-white hover:bg-emerald-950/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-lime-400' : 'text-gray-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar User Info */}
        <div className="pt-6 border-t border-emerald-500/15 space-y-3">
          <div className="p-3 rounded-2xl bg-[#08170F] border border-emerald-500/20 flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-lime-400 text-black font-bold flex items-center justify-center text-xs">
              RP
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-white truncate">
                {onboardingData?.farmerName || 'Ramesh Patel'}
              </div>
              <div className="text-[10px] font-mono text-emerald-400 truncate">
                {onboardingData?.farmName || 'GreenValley Farm'} • 2.4 Ac
              </div>
            </div>
          </div>

          <button
            onClick={() => setCurrentView('landing')}
            className="w-full py-2 px-3 rounded-xl border border-white/10 hover:border-red-500/40 text-xs font-mono text-gray-400 hover:text-red-300 hover:bg-red-950/20 transition-all flex items-center justify-center gap-2"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Exit to Website</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#040A06] overflow-y-auto">
        
        {/* Top Header Navbar */}
        <header className="h-16 border-b border-emerald-500/15 px-6 flex items-center justify-between bg-[#06120A]/70 backdrop-blur-xl sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
              className="md:hidden p-2 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-emerald-400"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display font-bold text-lg text-white hidden sm:block">
              Agricultural Operational Telemetry
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#08180E] border border-emerald-500/20 text-xs font-mono text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-lime-400 animate-pulse" />
              <span>Telemetry Node #402: Online (4.2 ms)</span>
            </div>

            <button
              onClick={() => setCurrentView('landing')}
              className="text-xs font-mono text-emerald-400 hover:text-white px-3 py-1.5 rounded-lg border border-emerald-500/30 hover:bg-emerald-900/30 transition-all"
            >
              Home Page
            </button>
          </div>
        </header>

        {/* Dashboard Body */}
        <div className="p-6 sm:p-8 space-y-8 max-w-7xl mx-auto w-full">
          
          {/* Greeting Banner */}
          <div className="rounded-3xl bg-gradient-to-r from-[#091F13] via-[#0A2616] to-[#081A0F] border-2 border-emerald-500/35 p-6 sm:p-8 shadow-2xl relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Autonomous Optimization Active</span>
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                Good Morning, {onboardingData?.farmerName?.split(' ')[0] || 'Farmer'} 👋
              </h2>
              <p className="text-sm text-gray-300 font-light">
                Your Farm is <strong className="text-lime-400 font-bold">86% Optimized Today</strong> with 3 predictive resource actions queued.
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="p-4 rounded-2xl bg-black/40 border border-lime-400/30 text-center">
                <span className="text-[10px] font-mono text-gray-400 uppercase block">
                  EFFICIENCY RATING
                </span>
                <span className="text-3xl font-display font-black text-lime-400">
                  86%
                </span>
              </div>
            </div>
          </div>

          {/* 4 Quick Telemetry Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Water Saved */}
            <div className="p-5 rounded-2xl bg-[#07170E]/80 border border-cyan-500/25">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <Droplet className="w-4 h-4 text-cyan-400" />
                  Water Saved Today
                </span>
                <span className="text-[10px] font-mono text-cyan-400 font-bold">+28%</span>
              </div>
              <div className="text-3xl font-display font-extrabold text-cyan-300">
                1,420 L
              </div>
              <span className="text-[11px] font-mono text-gray-400 mt-1 block">
                Preserved in reservoir buffer
              </span>
            </div>

            {/* Energy Saved */}
            <div className="p-5 rounded-2xl bg-[#07170E]/80 border border-amber-500/25">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <Sun className="w-4 h-4 text-amber-400" />
                  Energy Saved
                </span>
                <span className="text-[10px] font-mono text-amber-400 font-bold">Solar Drive</span>
              </div>
              <div className="text-3xl font-display font-extrabold text-amber-300">
                18.4 kWh
              </div>
              <span className="text-[11px] font-mono text-gray-400 mt-1 block">
                ₹340 power tariff avoided
              </span>
            </div>

            {/* Crop Health */}
            <div className="p-5 rounded-2xl bg-[#07170E]/80 border border-emerald-500/25">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <Sprout className="w-4 h-4 text-emerald-400" />
                  Crop Health
                </span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold">Optimal</span>
              </div>
              <div className="text-3xl font-display font-extrabold text-emerald-300">
                94%
              </div>
              <span className="text-[11px] font-mono text-gray-400 mt-1 block">
                NDVI vigor metric high
              </span>
            </div>

            {/* Weather Risk */}
            <div className="p-5 rounded-2xl bg-[#07170E]/80 border border-purple-500/25">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <CloudSun className="w-4 h-4 text-purple-400" />
                  Weather Risk
                </span>
                <span className="text-[10px] font-mono text-purple-400 font-bold">Rain Alert</span>
              </div>
              <div className="text-xl font-display font-bold text-white mt-1">
                Rain in 18 hrs
              </div>
              <span className="text-[11px] font-mono text-gray-400 mt-1 block">
                72% probability at dawn
              </span>
            </div>

          </div>

          {/* AI TODAY: 3 Recommendations Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-md bg-lime-400/20 text-lime-400">
                  <Sparkles className="w-4 h-4" />
                </span>
                <h3 className="font-display font-bold text-lg text-white">
                  AI TODAY — Actionable Recommendations
                </h3>
              </div>
              <span className="text-xs font-mono text-gray-400">
                Click “Apply Directive” to schedule automated execution
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {recommendations.map((rec) => {
                const Icon = rec.icon;
                const isApproved = rec.status === 'approved';

                return (
                  <div
                    key={rec.id}
                    className={`p-5 rounded-2xl border transition-all duration-300 flex flex-col justify-between ${
                      isApproved
                        ? 'bg-[#0A2417] border-lime-400/70 shadow-lg ring-1 ring-lime-400/30'
                        : `bg-[#07170E] ${rec.border}`
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <div className={`p-2 rounded-xl ${rec.bg} text-white`}>
                          <Icon className={`w-5 h-5 ${rec.color}`} />
                        </div>
                        <span className="text-[11px] font-mono font-bold text-lime-300 bg-lime-950/80 px-2 py-0.5 rounded border border-lime-500/30">
                          {rec.saving}
                        </span>
                      </div>

                      <h4 className="font-display font-bold text-base text-white mb-1.5 leading-snug">
                        {rec.title}
                      </h4>

                      <p className="text-xs text-gray-300 font-light leading-relaxed mb-4">
                        {rec.detail}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                      {isApproved ? (
                        <span className="inline-flex items-center gap-1 text-xs font-mono text-lime-400 font-bold">
                          <CheckCircle2 className="w-4 h-4" />
                          Directive Scheduled
                        </span>
                      ) : (
                        <button
                          onClick={() => handleApproveRec(rec.id)}
                          className="w-full py-2 rounded-xl bg-lime-400 hover:bg-lime-300 text-black font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow"
                        >
                          <span>Apply Directive</span>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Zones Live Operational Matrix */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-lg text-white">
                Farm Zones Telemetry Matrix
              </h3>
              <span className="text-xs font-mono text-emerald-400">
                4 Field Zones Synchronized
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {INITIAL_ZONES.map((zone) => (
                <div
                  key={zone.id}
                  className="p-5 rounded-2xl bg-[#07170E] border border-emerald-500/20 hover:border-emerald-500/40 transition-colors"
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="font-mono text-xs font-bold text-white block">
                        {zone.name}
                      </span>
                      <span className="text-xs text-lime-300 font-medium">
                        {zone.crop} ({zone.area})
                      </span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                      {zone.cropHealth}% Health
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-gray-300 pt-2 border-t border-white/5">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Soil Moisture:</span>
                      <span className="font-mono font-bold text-cyan-300">{zone.soilMoisture}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Canopy Temp:</span>
                      <span className="font-mono font-bold text-amber-300">{zone.temperature}°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Water Demand:</span>
                      <span className="font-mono font-bold text-lime-300">{zone.waterRequirement} L</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 text-[11px] text-gray-400 font-light border-t border-white/5 line-clamp-2">
                    {zone.aiRecommendation}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </main>

    </div>
  );
};
