import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { 
  Sprout, 
  Sun, 
  Droplet, 
  Radio, 
  Database, 
  Cpu, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft,
  Sparkles,
  Zap
} from 'lucide-react';
import { AppView, OnboardingState } from '../types';

interface OnboardingViewProps {
  setCurrentView: (view: AppView) => void;
  onboardingData: OnboardingState;
  setOnboardingData: React.Dispatch<React.SetStateAction<OnboardingState>>;
}

export const OnboardingView: React.FC<OnboardingViewProps> = ({
  setCurrentView,
  onboardingData,
  setOnboardingData
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isActivating, setIsActivating] = useState(false);

  // Available crop options
  const cropChoices = [
    'Tomato (Hybrid)',
    'Chilli & Capsicum',
    'Paddy / Rice',
    'Organic Greens',
    'Cotton',
    'Sugarcane',
    'Maize',
    'Pomegranate'
  ];

  const handleToggleCrop = (crop: string) => {
    setOnboardingData((prev) => {
      const exists = prev.crops.includes(crop);
      return {
        ...prev,
        crops: exists ? prev.crops.filter((c) => c !== crop) : [...prev.crops, crop]
      };
    });
  };

  const handleToggleResource = (key: 'solar' | 'pump' | 'sensors' | 'waterTank') => {
    setOnboardingData((prev) => ({
      ...prev,
      connectedResources: {
        ...prev.connectedResources,
        [key]: !prev.connectedResources[key]
      }
    }));
  };

  const handleActivateIntelligence = () => {
    setIsActivating(true);

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10B981', '#84CC16', '#FDE047']
      });
    } catch (e) {
      // fallback safe
    }

    setTimeout(() => {
      setIsActivating(false);
      setCurrentStep(4);
    }, 1200);
  };

  const handleComplete = () => {
    setCurrentView('dashboard');
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[#040A06] py-16 overflow-hidden text-white">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[500px] bg-emerald-950/20 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute inset-0 bg-tech-grid opacity-25 pointer-events-none" />

      <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 w-full">
        
        {/* Step Indicator Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-xs font-mono text-gray-400 mb-2">
            <span className="text-lime-400 font-bold uppercase tracking-wider">
              AGRIOS Autonomous Setup
            </span>
            <span>Step {currentStep} of 4</span>
          </div>

          {/* Stepper bar */}
          <div className="grid grid-cols-4 gap-2">
            {[1, 2, 3, 4].map((stepNum) => (
              <div
                key={stepNum}
                className={`h-2 rounded-full transition-all duration-300 ${
                  currentStep >= stepNum
                    ? 'bg-gradient-to-r from-lime-400 to-emerald-400'
                    : 'bg-emerald-950/60 border border-emerald-500/20'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Step Card Container */}
        <div className="rounded-3xl bg-[#08180E]/90 border-2 border-emerald-500/35 p-6 sm:p-10 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
          
          <AnimatePresence mode="wait">
            
            {/* STEP 1: Tell us about your farm */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                    STEP 01
                  </span>
                  <h2 className="font-display text-2xl sm:text-3xl font-black text-white mt-1">
                    Tell us about your farm
                  </h2>
                  <p className="text-xs sm:text-sm text-gray-300 font-light mt-1">
                    Confirm your parcel boundary and water extraction setup for localized microclimate tuning.
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-mono text-gray-400 block mb-1">
                      Farm Name or Plot Nickname
                    </label>
                    <input
                      type="text"
                      value={onboardingData.farmName}
                      onChange={(e) => setOnboardingData({ ...onboardingData, farmName: e.target.value })}
                      className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-lime-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-mono text-gray-400 block mb-1">
                        Cultivated Acreage
                      </label>
                      <input
                        type="text"
                        value={onboardingData.farmSize}
                        onChange={(e) => setOnboardingData({ ...onboardingData, farmSize: e.target.value })}
                        className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-lime-400"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-mono text-gray-400 block mb-1">
                        Location / Sub-District
                      </label>
                      <input
                        type="text"
                        value={onboardingData.location}
                        onChange={(e) => setOnboardingData({ ...onboardingData, location: e.target.value })}
                        className="w-full bg-[#040C07] border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-lime-400"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="px-6 py-3 rounded-xl bg-lime-400 text-black font-bold text-xs flex items-center gap-2 hover:bg-lime-300 transition-all shadow-lg shadow-lime-400/20"
                  >
                    <span>Continue to Crops</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 2: Choose your crops */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                    STEP 02
                  </span>
                  <h2 className="font-display text-2xl sm:text-3xl font-black text-white mt-1">
                    Choose your crops
                  </h2>
                  <p className="text-xs sm:text-sm text-gray-300 font-light mt-1">
                    Select all crops currently planted or planned for the upcoming seasonal rotation.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {cropChoices.map((crop) => {
                    const isSelected = onboardingData.crops.includes(crop);
                    return (
                      <button
                        key={crop}
                        onClick={() => handleToggleCrop(crop)}
                        className={`p-4 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-2 ${
                          isSelected
                            ? 'bg-lime-950/70 border-lime-400 text-lime-300 ring-2 ring-lime-400/40 shadow-lg'
                            : 'bg-[#040C07] border-emerald-500/20 text-gray-300 hover:border-emerald-500/40'
                        }`}
                      >
                        <Sprout className={`w-5 h-5 ${isSelected ? 'text-lime-400' : 'text-gray-500'}`} />
                        <span className="text-xs font-semibold">{crop}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="px-5 py-3 rounded-xl border border-white/10 text-xs font-mono text-gray-400 hover:text-white flex items-center gap-2"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    onClick={() => setCurrentStep(3)}
                    className="px-6 py-3 rounded-xl bg-lime-400 text-black font-bold text-xs flex items-center gap-2 hover:bg-lime-300 transition-all shadow-lg shadow-lime-400/20"
                  >
                    <span>Connect Resources</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 3: Connect your resources */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                    STEP 03
                  </span>
                  <h2 className="font-display text-2xl sm:text-3xl font-black text-white mt-1">
                    Connect your resources
                  </h2>
                  <p className="text-xs sm:text-sm text-gray-300 font-light mt-1">
                    Toggle which hardware and storage assets AGRIOS will monitor and schedule.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Solar */}
                  <div
                    onClick={() => handleToggleResource('solar')}
                    className={`cursor-pointer p-4 rounded-2xl border transition-all flex items-center justify-between ${
                      onboardingData.connectedResources.solar
                        ? 'bg-amber-950/50 border-amber-400 text-white'
                        : 'bg-[#040C07] border-white/10 text-gray-400'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
                        <Sun className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs font-bold font-mono">SOLAR ARRAYS</div>
                        <div className="text-[11px] text-gray-400">PV Generation Telemetry</div>
                      </div>
                    </div>
                    <CheckCircle2 className={`w-5 h-5 ${onboardingData.connectedResources.solar ? 'text-amber-400' : 'text-gray-600'}`} />
                  </div>

                  {/* Pump */}
                  <div
                    onClick={() => handleToggleResource('pump')}
                    className={`cursor-pointer p-4 rounded-2xl border transition-all flex items-center justify-between ${
                      onboardingData.connectedResources.pump
                        ? 'bg-cyan-950/50 border-cyan-400 text-white'
                        : 'bg-[#040C07] border-white/10 text-gray-400'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400">
                        <Droplet className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs font-bold font-mono">IRRIGATION PUMP</div>
                        <div className="text-[11px] text-gray-400">Smart VFD / Solenoid Valves</div>
                      </div>
                    </div>
                    <CheckCircle2 className={`w-5 h-5 ${onboardingData.connectedResources.pump ? 'text-cyan-400' : 'text-gray-600'}`} />
                  </div>

                  {/* Sensors */}
                  <div
                    onClick={() => handleToggleResource('sensors')}
                    className={`cursor-pointer p-4 rounded-2xl border transition-all flex items-center justify-between ${
                      onboardingData.connectedResources.sensors
                        ? 'bg-emerald-950/50 border-emerald-400 text-white'
                        : 'bg-[#040C07] border-white/10 text-gray-400'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
                        <Radio className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs font-bold font-mono">SOIL SENSORS</div>
                        <div className="text-[11px] text-gray-400">Moisture, EC & Temp Probes</div>
                      </div>
                    </div>
                    <CheckCircle2 className={`w-5 h-5 ${onboardingData.connectedResources.sensors ? 'text-emerald-400' : 'text-gray-600'}`} />
                  </div>

                  {/* Water Tank */}
                  <div
                    onClick={() => handleToggleResource('waterTank')}
                    className={`cursor-pointer p-4 rounded-2xl border transition-all flex items-center justify-between ${
                      onboardingData.connectedResources.waterTank
                        ? 'bg-blue-950/50 border-blue-400 text-white'
                        : 'bg-[#040C07] border-white/10 text-gray-400'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400">
                        <Database className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs font-bold font-mono">WATER RESERVOIR</div>
                        <div className="text-[11px] text-gray-400">Ultrasonic Level Buffer</div>
                      </div>
                    </div>
                    <CheckCircle2 className={`w-5 h-5 ${onboardingData.connectedResources.waterTank ? 'text-blue-400' : 'text-gray-600'}`} />
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="px-5 py-3 rounded-xl border border-white/10 text-xs font-mono text-gray-400 hover:text-white flex items-center gap-2"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    onClick={handleActivateIntelligence}
                    disabled={isActivating}
                    className="px-7 py-3 rounded-xl bg-gradient-to-r from-lime-400 to-emerald-400 text-black font-bold text-xs flex items-center gap-2 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-lime-400/30"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isActivating ? 'Synthesizing Neural Mesh...' : 'Activate AGRIOS Intelligence'}</span>
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 4: Activate AGRIOS Intelligence / Ready */}
            {currentStep === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-6 space-y-6"
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-lime-400 via-emerald-400 to-lime-300 text-black flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/40">
                  <Cpu className="w-10 h-10 animate-pulse" />
                </div>

                <div className="space-y-2 max-w-lg mx-auto">
                  <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                    AUTONOMOUS ACTIVATION COMPLETE
                  </span>
                  <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white">
                    “Your farm is ready to think.”
                  </h2>
                  <p className="text-sm text-gray-300 font-light leading-relaxed">
                    AGRIOS has initialized the closed-loop neural decision model for {onboardingData.farmName} ({onboardingData.farmSize}). Real-time telemetry is streaming from your connected nodes.
                  </p>
                </div>

                {/* Status Badges */}
                <div className="flex flex-wrap items-center justify-center gap-3 text-xs font-mono">
                  <span className="px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-lime-400" />
                    Telemetry Synchronized
                  </span>
                  <span className="px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    Weather Radar Online
                  </span>
                  <span className="px-3 py-1 rounded-full bg-amber-950 border border-amber-500/40 text-amber-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                    Solar Tracking Active
                  </span>
                </div>

                <div className="pt-4">
                  <button
                    onClick={handleComplete}
                    className="px-9 py-4 rounded-xl bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 text-gray-950 font-display font-extrabold text-sm flex items-center justify-center gap-2.5 mx-auto hover:scale-105 active:scale-95 transition-transform shadow-2xl shadow-lime-400/40"
                  >
                    <span>Enter My Farm →</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </div>

      </div>
    </div>
  );
};
