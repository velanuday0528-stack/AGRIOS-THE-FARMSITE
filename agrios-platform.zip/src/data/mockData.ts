import { FarmZone, DropletMilestone, SimulatorParams, SimulatorOutputs } from '../types';

export const INITIAL_ZONES: FarmZone[] = [
  {
    id: 'zone-a',
    name: 'ZONE A',
    crop: 'Tomato',
    area: '1.2 Acres',
    soilMoisture: 38,
    temperature: 28,
    cropHealth: 96,
    waterRequirement: 350,
    energyRequirement: 2.4,
    aiRecommendation: 'Optimal moisture retention. Delay drip cycle by 4 hours.',
    expectedWaterSaving: '15%',
    expectedYieldImpact: '+6.2%',
    status: 'optimal',
    coordinates: { x: 22, y: 35 }
  },
  {
    id: 'zone-b',
    name: 'ZONE B',
    crop: 'Chilli',
    area: '0.8 Acres',
    soilMoisture: 29,
    temperature: 31,
    cropHealth: 92,
    waterRequirement: 420,
    energyRequirement: 3.1,
    aiRecommendation: 'Irrigate 420 L via solar pump at 1:15 PM peak solar window.',
    expectedWaterSaving: '18%',
    expectedYieldImpact: '+7.4%',
    status: 'attention',
    coordinates: { x: 45, y: 55 }
  },
  {
    id: 'zone-c',
    name: 'ZONE C',
    crop: 'Paddy',
    area: '2.5 Acres',
    soilMoisture: 62,
    temperature: 27,
    cropHealth: 95,
    waterRequirement: 890,
    energyRequirement: 5.6,
    aiRecommendation: 'Water table saturated. Hold ponding water until Thursday night.',
    expectedWaterSaving: '24%',
    expectedYieldImpact: '+4.8%',
    status: 'optimal',
    coordinates: { x: 70, y: 30 }
  },
  {
    id: 'zone-d',
    name: 'ZONE D',
    crop: 'Organic Vegetables',
    area: '1.0 Acres',
    soilMoisture: 32,
    temperature: 29,
    cropHealth: 94,
    waterRequirement: 290,
    energyRequirement: 1.8,
    aiRecommendation: 'Micro-sprinkler activation recommended at dusk (6:15 PM).',
    expectedWaterSaving: '14%',
    expectedYieldImpact: '+8.1%',
    status: 'scheduled',
    coordinates: { x: 78, y: 72 }
  }
];

export const DROPLET_MILESTONES: DropletMilestone[] = [
  {
    id: 'rain',
    title: 'Rain / Inflow',
    subtitle: 'Capturing Every Natural Millimetre',
    icon: 'CloudRain',
    waterUsed: '0 L (Passive)',
    waterSaved: '+420 L Harvested',
    energyRequired: '0.0 kWh',
    expectedCropValue: 'Baseline',
    efficiencyGain: '+100% Free Intake',
    detail: 'Rain sensors and micro-catchment dams channel natural precipitation directly to the telemetry buffer tank before running electrical pumps.'
  },
  {
    id: 'storage',
    title: 'Storage & Reservoir',
    subtitle: 'Zero Evaporation Smart Tank',
    icon: 'Database',
    waterUsed: '1,200 L Buffered',
    waterSaved: '180 L Evap Loss Prevented',
    energyRequired: '0.4 kWh Solar Pumping',
    expectedCropValue: 'Preserved asset',
    efficiencyGain: '+15% Buffer Longevity',
    detail: 'Automated covered reservoir with ultrasonic depth telemetry prevents thermal evaporation and algae growth while scheduling pump pressurization.'
  },
  {
    id: 'soil',
    title: 'Soil Subsurface',
    subtitle: 'Precision Root-Zone Delivery',
    icon: 'Layers',
    waterUsed: '840 L Targeted',
    waterSaved: '310 L Runoff Avoided',
    energyRequired: '1.2 kWh Solar Inverter',
    expectedCropValue: '+₹3,200 Retained Quality',
    efficiencyGain: '+28% Percolation Efficacy',
    detail: 'Subsurface drip emitters release water only at capillary suction thresholds, avoiding weed growth and surface baking.'
  },
  {
    id: 'root',
    title: 'Root Absorption',
    subtitle: 'Osmotic Nutrient Uptake',
    icon: 'GitFork',
    waterUsed: '780 L Absorbed',
    waterSaved: '95 L Leaching Prevented',
    energyRequired: '0.0 kWh (Biological)',
    expectedCropValue: '+₹5,800 Root Biomass',
    efficiencyGain: '+34% Nutrient Density',
    detail: 'Continuous electrical conductivity (EC) sensors ensure the root zone stays in the osmotic sweet spot without salt accumulation.'
  },
  {
    id: 'crop',
    title: 'Crop Transpiration',
    subtitle: 'Vigorous Vegetative Vitality',
    icon: 'Sprout',
    waterUsed: '720 L Transpired',
    waterSaved: 'Stomatal Stress Prevented',
    energyRequired: 'Natural Photosynthesis',
    expectedCropValue: '+18% Higher Biomass',
    efficiencyGain: '+94% Crop Health Index',
    detail: 'Infrared canopy temperature sensors confirm stomatal openness is maximized during peak photosynthesis while avoiding heat wilting.'
  },
  {
    id: 'harvest',
    title: 'Market Harvest',
    subtitle: 'Grade-A Premium Produce',
    icon: 'ShoppingBag',
    waterUsed: 'Calculated Per Kg',
    waterSaved: '30% Total Resource Saved',
    energyRequired: 'Net Positive Solar',
    expectedCropValue: '+₹42,000 Premium Realization',
    efficiencyGain: '+22% Farm Net Margin',
    detail: 'Produce harvested at peak moisture firmness achieves longer shelf-life, minimal post-harvest shrinkage, and commanding Grade-A market pricing.'
  }
];

export const TIMELINE_ITEMS = [
  {
    day: 'TODAY',
    label: 'Current Status',
    moisture: '34% Soil Moisture',
    temp: '29°C Ambient',
    solar: '7.8 kWh Solar Peak',
    forecast: 'Sunny / Mild Wind',
    badge: 'Real-time telemetry',
    color: 'emerald'
  },
  {
    day: 'TOMORROW',
    label: 'Weather Alert',
    moisture: 'Rain Probability: 72%',
    temp: '24°C Cooler',
    solar: '3.2 kWh Overcast',
    forecast: 'Heavy localized shower expected 3 PM',
    badge: 'Precipitation predicted',
    color: 'cyan'
  },
  {
    day: '+3 DAYS',
    label: 'Thermal Wave',
    moisture: 'Rapid Evaporation Risk',
    temp: '37°C High Heat',
    solar: '9.4 kWh High Radiance',
    forecast: 'Dry winds & zero cloud cover',
    badge: 'Stress prevention',
    color: 'amber'
  },
  {
    day: '+7 DAYS',
    label: 'Canal Schedule',
    moisture: 'Reservoir Buffer Needed',
    temp: '32°C Normal',
    solar: '8.1 kWh Steady',
    forecast: 'Canal shutoff scheduled for maintenance',
    badge: 'Resource rationing',
    color: 'emerald'
  }
];

export const FARMER_VOICE_DEMOS: Record<string, { query: string; response: string; audioDuration: number }> = {
  Tamil: {
    query: '“Innaiku thanni paaychalama?”',
    response: '“Aama. Evening 4:30 PM-ku 20 minutes irrigation pannunga. Tomorrow rain probability 68%, so excess watering avoid pannalam.”',
    audioDuration: 5
  },
  Hindi: {
    query: '“क्या आज खेत में पानी देना चाहिए?”',
    response: '“हाँ, शाम 4:30 बजे 20 मिनट के लिए ड्रिप चलाएं। कल 68% बारिश की संभावना है, इसलिए अतिरिक्त पानी की बचत करें।”',
    audioDuration: 5
  },
  Telugu: {
    query: '“ఈరోజు పొలానికి నీళ్లు పెట్టాలా?”',
    response: '“అవును, సాయంత్రం 4:30 గంటలకు 20 నిమిషాలు బిందు సేద్యం చేయండి. రేపు 68% వర్ష సూచన ఉంది, అధిక నీటిని ఆపండి.”',
    audioDuration: 5
  },
  Kannada: {
    query: '“ಇವತ್ತು ನೀರು ಹಾಯಿಸಬೇಕಾ?”',
    response: '“ಹೌದು, ಸಂಜೆ 4:30 ಕ್ಕೆ 20 ನಿಮಿಷ ನೀರಾವರಿ ಮಾಡಿ. ನಾಳೆ ಮಳೆಯಾಗುವ ಸಾಧ್ಯತೆ 68% ಇದೆ, ಹೆಚ್ಚುವರಿ ನೀರು ಪೋಲಾಗುವುದನ್ನು ತಪ್ಪಿಸಿ.”',
    audioDuration: 5
  },
  Marathi: {
    query: '“आज पिकाला पाणी द्यावे का?”',
    response: '“होय, संध्याकाळी 4:30 वाजता 20 मिनिटे ठिबक सिंचन सुरू करा. उद्या 68% पावसाची शक्यता आहे, त्यामुळे अति पाणी टाळा.”',
    audioDuration: 5
  },
  English: {
    query: '“Should I irrigate today?”',
    response: '“Yes. Run drip irrigation at 4:30 PM for 20 minutes. Rain probability tomorrow is 68%, so excess watering can be avoided.”',
    audioDuration: 4
  }
};

export function calculateSimulator(params: SimulatorParams): SimulatorOutputs {
  const { waterAvailability, temperature, solarAvailability, rainProbability } = params;

  // Realistic dynamic climate-agronomic algorithm
  let waterNeed = 1200;
  if (temperature > 32) waterNeed += (temperature - 32) * 55;
  if (rainProbability > 50) waterNeed -= (rainProbability - 50) * 12;

  const waterSupplied = Math.round((waterAvailability / 100) * waterNeed);
  const waterSaved = Math.max(120, Math.round(waterNeed * (rainProbability / 200) + (solarAvailability > 70 ? 180 : 80)));
  const energyKwh = Number(((waterSupplied / 1000) * 1.8 * (1 - solarAvailability * 0.006)).toFixed(1));

  // Yield formula balancing moisture & heat stress
  let yieldScore = 94;
  if (temperature > 38) yieldScore -= (temperature - 38) * 3;
  if (waterAvailability < 40) yieldScore -= (40 - waterAvailability) * 0.8;
  if (rainProbability > 85) yieldScore -= 4; // root flooding risk
  yieldScore = Math.max(45, Math.min(99, Math.round(yieldScore)));

  // Resilience score combines all 4 factors
  const resilience = Math.max(50, Math.min(98, Math.round(
    (waterAvailability * 0.25) +
    ((45 - temperature) * 1.8) +
    (solarAvailability * 0.25) +
    (rainProbability * 0.15) +
    18
  )));

  // Cost calculation based on energy & water utility
  const cost = Math.round((energyKwh * 6.5) + (waterSupplied * 0.04));

  let rec = '';
  if (rainProbability > 60) {
    rec = `Reduce irrigation by ${Math.round(rainProbability * 0.25)}% and reserve ${waterSaved} L for the predicted rainfall cushion.`;
  } else if (temperature > 35 && solarAvailability > 75) {
    rec = `Utilize 100% solar surplus at 1:15 PM to pre-cool soil canopy before peak heat wave.`;
  } else if (waterAvailability < 35) {
    rec = `Deficit irrigation mode active: Focus 380 L exclusively on Zone A & B root zones.`;
  } else {
    rec = `Normal automated cycle: Schedule 22-min drip pulsing at 4:45 PM using 82% solar energy.`;
  }

  return {
    expectedYield: yieldScore,
    waterConsumption: waterSupplied,
    energyConsumption: energyKwh,
    estimatedCost: cost,
    resilienceScore: resilience,
    aiRecommendation: rec,
    savedWater: waterSaved
  };
}
