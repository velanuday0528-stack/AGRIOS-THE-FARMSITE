import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LandingView } from './views/LandingView';
import { LoginView } from './views/LoginView';
import { SignupView } from './views/SignupView';
import { OnboardingView } from './views/OnboardingView';
import { DashboardView } from './views/DashboardView';
import { AiAssistantModal } from './components/AiAssistantModal';
import { AppView, OnboardingState } from './types';

export const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>('landing');

  // Shared state for farm onboarding data
  const [onboardingData, setOnboardingData] = useState<OnboardingState>({
    step: 1,
    farmName: 'Cauvery Bio-Delta Farm',
    farmerName: 'Ramesh Patel',
    mobile: '+91 98450 12345',
    location: 'Coimbatore, Tamil Nadu',
    farmSize: '2.4 Acres',
    primaryCrop: 'Tomato (Hybrid)',
    crops: ['Tomato (Hybrid)', 'Chilli & Capsicum'],
    irrigationType: 'Precision Drip & Sprinkler',
    energySource: 'Solar Hybrid (Grid Backup)',
    language: 'Tamil',
    connectedResources: {
      solar: true,
      pump: true,
      sensors: true,
      waterTank: true
    }
  });

  // Handle URL hash changes for quick navigation & bookmarking
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (['landing', 'login', 'signup', 'onboarding', 'dashboard'].includes(hash)) {
        setCurrentView(hash as AppView);
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Update hash and scroll to top when view changes
  const changeView = (view: AppView) => {
    setCurrentView(view);
    window.location.hash = view === 'landing' ? '' : view;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#060F09] text-[#E6EFE8] font-sans relative selection:bg-emerald-500/30 selection:text-lime-300">
      
      {/* Sticky Navbar (visible on landing view) */}
      {currentView === 'landing' && (
        <Navbar
          currentView={currentView}
          setCurrentView={changeView}
        />
      )}

      {/* Primary Dynamic View Routing */}
      {currentView === 'landing' && (
        <LandingView setCurrentView={changeView} />
      )}

      {currentView === 'login' && (
        <LoginView setCurrentView={changeView} />
      )}

      {currentView === 'signup' && (
        <SignupView
          setCurrentView={changeView}
          setOnboardingData={setOnboardingData}
        />
      )}

      {currentView === 'onboarding' && (
        <OnboardingView
          setCurrentView={changeView}
          onboardingData={onboardingData}
          setOnboardingData={setOnboardingData}
        />
      )}

      {currentView === 'dashboard' && (
        <DashboardView
          setCurrentView={changeView}
          onboardingData={onboardingData}
        />
      )}

      {/* Global Floating AI Assistant Modal ("Ask AGRIOS") */}
      <AiAssistantModal />

    </div>
  );
};

export default App;
