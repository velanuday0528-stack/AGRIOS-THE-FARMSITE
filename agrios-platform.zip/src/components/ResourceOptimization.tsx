import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MapPin, 
  Droplets, 
  Thermometer, 
  Sprout, 
  Zap, 
  TrendingUp, 
  CheckCircle2, 
  Info,
  Maximize2,
  Sliders
} from 'lucide-react';
import { INITIAL_ZONES } from '../data/mockData';
import { FarmZone } from '../types';

export const ResourceOptimization: React.FC = () => {
  const [zones] = useState<FarmZone[]>(INITIAL_ZONES);
  const [selectedZone, setSelectedZone] = useState<FarmZone>(INITIAL_ZONES[1]); // Zone B (Chilli)
  const [hoveredZoneId, setHoveredZoneId] = useState<string | null>(null);

  return (
    <section id="zones" className="relative py-28 bg-[#060F09] overflow-hidden">
      {/* Background ambient light */}
      <div className="absolute top-1/4 left-1/3 w-[600px] h-[600px] bg-emerald-950/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute inset-0 bg-dot-grid opacity-20 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <MapPin className="w-3.5 h-3.5" />
            <span>Interactive Spatial Telemetry</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Smart Resource <span className="text-gradient-emerald">Optimization</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            Every square metre of soil has different topology, drainage, and crop physiology. Hover or click any farm zone to inspect live micro-telemetry and autonomous AI directives.
          </p>
        </div>

        {/* Grid: Interactive Farm Map (Left/Center) + Glassmorphic Inspector Card (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Farm Visual Map Canvas (8 cols) */}
          <div className="lg:col-span-7 bg-[#08150D]/80 border border-emerald-500/25 rounded-3xl p-6 sm:p-8 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
            
            {/* Top Toolbar */}
            <div className="flex items-center justify-between pb-4 border-b border-emerald-500/15 mb-6">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-lime-400 animate-ping" />
                <span className="font-mono text-xs text-white font-bold uppercase tracking-wider">
                  Live Farm Orthomosaic Map
                </span>
                <span className="text-[11px] font-mono text-emerald-400/80 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  4 Active Zones
                </span>
              </div>
              <div className="text-[11px] font-mono text-gray-400 hidden sm:block">
                GPS: 11.0168° N, 76.9558° E
              </div>
            </div>

            {/* Simulated Interactive Vector Field Map */}
            <div className="relative aspect-[16/10] w-full rounded-2xl bg-[#040C07] border border-emerald-500/20 overflow-hidden group">
              {/* Field Rows Texture */}
              <div className="absolute inset-0 bg-tech-grid opacity-30" />
              <div className="absolute inset-0 bg-gradient-to-tr from-emerald-950/40 via-transparent to-lime-950/20 pointer-events-none" />

              {/* 4 Interactive Zone Polygons */}
              <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-3 p-4">
                {zones.map((zone) => {
                  const isSelected = selectedZone.id === zone.id;
                  const isHovered = hoveredZoneId === zone.id;

                  return (
                    <motion.div
                      key={zone.id}
                      onClick={() => setSelectedZone(zone)}
                      onMouseEnter={() => setHoveredZoneId(zone.id)}
                      onMouseLeave={() => setHoveredZoneId(null)}
                      whileHover={{ scale: 1.015 }}
                      className={`cursor-pointer rounded-xl p-4 transition-all duration-300 relative flex flex-col justify-between border backdrop-blur-sm ${
                        isSelected
                          ? 'bg-emerald-900/40 border-lime-400 shadow-xl shadow-lime-950/50 ring-2 ring-lime-400/40'
                          : isHovered
                          ? 'bg-emerald-950/40 border-emerald-400/60'
                          : 'bg-[#06140B]/80 border-emerald-500/20 hover:border-emerald-500/40'
                      }`}
                    >
                      {/* Zone Header */}
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-mono text-xs font-bold text-white tracking-wide block">
                            {zone.name}
                          </span>
                          <span className="text-xs text-lime-300 font-semibold">
                            {zone.crop}
                          </span>
                        </div>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                          zone.status === 'optimal'
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                            : zone.status === 'attention'
                            ? 'bg-amber-950 text-amber-300 border-amber-500/40'
                            : 'bg-cyan-950 text-cyan-300 border-cyan-500/40'
                        }`}>
                          {zone.area}
                        </span>
                      </div>

                      {/* Live sensor indicators mini-badges */}
                      <div className="grid grid-cols-3 gap-1.5 pt-4 text-[10px] font-mono">
                        <div className="bg-black/40 rounded p-1 text-center">
                          <span className="text-gray-400 block">Moisture</span>
                          <span className={`font-bold ${zone.soilMoisture < 30 ? 'text-amber-300' : 'text-cyan-300'}`}>
                            {zone.soilMoisture}%
                          </span>
                        </div>
                        <div className="bg-black/40 rounded p-1 text-center">
                          <span className="text-gray-400 block">Health</span>
                          <span className="font-bold text-emerald-300">{zone.cropHealth}%</span>
                        </div>
                        <div className="bg-black/40 rounded p-1 text-center">
                          <span className="text-gray-400 block">Need</span>
                          <span className="font-bold text-lime-300">{zone.waterRequirement} L</span>
                        </div>
                      </div>

                      {/* Pulsing IoT Sensor Beacon Pin */}
                      <div className="absolute bottom-2 right-2 flex items-center gap-1">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lime-400 opacity-75" />
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-lime-400" />
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Quick Map Controls Footer */}
            <div className="mt-4 pt-3 flex flex-wrap items-center justify-between text-xs font-mono text-gray-400 border-t border-emerald-500/15">
              <span className="flex items-center gap-2">
                <Info className="w-3.5 h-3.5 text-lime-400" />
                Select any zone to load active AI recommendation
              </span>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" /> Optimal
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400" /> Attention
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" /> Scheduled
                </span>
              </div>
            </div>

          </div>

          {/* Glassmorphic Zone Inspector Card (5 cols) */}
          <div className="lg:col-span-5">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedZone.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="rounded-3xl bg-[#091B11]/90 border-2 border-emerald-500/35 p-6 sm:p-7 backdrop-blur-2xl shadow-2xl space-y-6 relative overflow-hidden"
              >
                {/* Ambient glow */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-lime-500/10 rounded-full blur-3xl pointer-events-none" />

                {/* Inspector Header */}
                <div className="flex items-center justify-between pb-4 border-b border-emerald-500/15">
                  <div>
                    <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                      ZONE TELEMETRY INSPECTOR
                    </span>
                    <h3 className="font-display text-2xl font-black text-white mt-0.5">
                      {selectedZone.name} — {selectedZone.crop}
                    </h3>
                  </div>
                  <span className="text-xs font-mono bg-emerald-950 text-emerald-300 px-3 py-1 rounded-full border border-emerald-500/30">
                    {selectedZone.area}
                  </span>
                </div>

                {/* 4 Sensor Gauges */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-xl bg-[#061209]/80 border border-emerald-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Soil Moisture</span>
                    </div>
                    <div className="text-xl font-display font-bold text-white flex items-baseline gap-1">
                      {selectedZone.soilMoisture}%
                      <span className="text-[10px] font-mono text-gray-400">volumetric</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#061209]/80 border border-emerald-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                      <span>Temperature</span>
                    </div>
                    <div className="text-xl font-display font-bold text-white flex items-baseline gap-1">
                      {selectedZone.temperature}°C
                      <span className="text-[10px] font-mono text-gray-400">canopy</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#061209]/80 border border-emerald-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Crop Health</span>
                    </div>
                    <div className="text-xl font-display font-bold text-emerald-300 flex items-baseline gap-1">
                      {selectedZone.cropHealth}%
                      <span className="text-[10px] font-mono text-emerald-500">Vigor</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#061209]/80 border border-emerald-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Zap className="w-3.5 h-3.5 text-lime-400" />
                      <span>Energy Needed</span>
                    </div>
                    <div className="text-xl font-display font-bold text-lime-300 flex items-baseline gap-1">
                      {selectedZone.energyRequirement}
                      <span className="text-[10px] font-mono text-gray-400">kWh Solar</span>
                    </div>
                  </div>
                </div>

                {/* AI Recommendation Box */}
                <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-lime-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>AI Recommended Action</span>
                  </div>
                  <p className="text-sm font-semibold text-white leading-relaxed">
                    “{selectedZone.aiRecommendation}”
                  </p>
                </div>

                {/* Impact Metrics (Water saving & yield impact) */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-[#07150C] border border-cyan-500/25">
                    <span className="text-[11px] font-mono text-gray-400 block">
                      Expected Water Saving
                    </span>
                    <span className="text-lg font-display font-extrabold text-cyan-300">
                      {selectedZone.expectedWaterSaving}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#07150C] border border-lime-500/25">
                    <span className="text-[11px] font-mono text-gray-400 block">
                      Expected Yield Impact
                    </span>
                    <span className="text-lg font-display font-extrabold text-lime-400">
                      {selectedZone.expectedYieldImpact}
                    </span>
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
};
