import React from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  Droplet, 
  Sun, 
  Zap, 
  Sprout, 
  AlertCircle, 
  ArrowRight, 
  CheckCircle2, 
  Activity,
  Layers,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { AppView } from '../types';

interface DashboardPreviewProps {
  setCurrentView: (view: AppView) => void;
}

export const DashboardPreview: React.FC<DashboardPreviewProps> = ({ setCurrentView }) => {
  return (
    <section className="relative py-28 bg-[#040A06] overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] bg-emerald-950/20 rounded-full blur-[160px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>Commercial-Grade Software</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            The AGRIOS <span className="text-gradient-emerald">Command Console</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            Designed for agronomists, commercial farm operators, and enterprise agricultural cooperatives who require instant operational clarity.
          </p>
        </div>

        {/* Dashboard Frame Preview */}
        <div className="max-w-5xl mx-auto">
          <div className="rounded-3xl bg-[#08170F]/90 border-2 border-emerald-500/30 p-6 sm:p-9 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
            
            {/* Top SaaS Header */}
            <div className="flex flex-wrap items-center justify-between pb-6 border-b border-emerald-500/15 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                <div className="h-4 w-px bg-white/10 ml-1" />
                <span className="font-mono text-xs text-gray-400 uppercase tracking-widest font-semibold">
                  agrios.os/live-farm-telemetry
                </span>
              </div>

              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1.5 text-xs font-mono text-lime-300 bg-lime-950/60 px-3 py-1 rounded-full border border-lime-500/30">
                  <span className="w-2 h-2 rounded-full bg-lime-400 animate-ping" />
                  STATUS: OPTIMAL
                </span>

                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-lime-400 to-emerald-400 text-black font-bold text-xs flex items-center gap-1.5 hover:scale-105 transition-transform shadow-lg shadow-emerald-500/20"
                >
                  <span>Launch Live Console</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Dashboard Content Mockup */}
            <div className="pt-6 space-y-6">
              
              {/* Row 1: Farm Overview Summary */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-[#061209] border border-emerald-500/20">
                  <span className="text-[11px] font-mono text-gray-400 uppercase block mb-1">
                    FARM AREA
                  </span>
                  <span className="text-xl font-display font-bold text-white">2.4 Acres</span>
                  <span className="text-[10px] font-mono text-emerald-400 block mt-0.5">Plot #AG-402</span>
                </div>

                <div className="p-4 rounded-2xl bg-[#061209] border border-emerald-500/20">
                  <span className="text-[11px] font-mono text-gray-400 uppercase block mb-1">
                    PRIMARY CROP
                  </span>
                  <span className="text-xl font-display font-bold text-white">Tomato (Hybrid)</span>
                  <span className="text-[10px] font-mono text-lime-400 block mt-0.5">Stage: Fruiting Cycle</span>
                </div>

                <div className="p-4 rounded-2xl bg-[#061209] border border-emerald-500/20">
                  <span className="text-[11px] font-mono text-gray-400 uppercase block mb-1">
                    OVERALL STATUS
                  </span>
                  <span className="text-xl font-display font-bold text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-5 h-5 text-lime-400" />
                    Optimal
                  </span>
                  <span className="text-[10px] font-mono text-gray-400 block mt-0.5">Zero alerts pending</span>
                </div>
              </div>

              {/* Row 2: Today's Metrics (4 columns) */}
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-gray-400 font-bold block mb-3">
                  TODAY’S TELEMETRY & EFFICIENCY
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-4 rounded-2xl bg-[#061209] border border-cyan-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Droplet className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Water</span>
                    </div>
                    <div className="text-2xl font-display font-bold text-cyan-300">
                      1,240 L
                    </div>
                    <span className="text-[10px] font-mono text-gray-400">Scheduled delivery</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#061209] border border-amber-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Sun className="w-3.5 h-3.5 text-amber-400" />
                      <span>Solar Power</span>
                    </div>
                    <div className="text-2xl font-display font-bold text-amber-300">
                      8.4 kWh
                    </div>
                    <span className="text-[10px] font-mono text-gray-400">PV Array Peak</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#061209] border border-lime-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Zap className="w-3.5 h-3.5 text-lime-400" />
                      <span>Energy Saved</span>
                    </div>
                    <div className="text-2xl font-display font-bold text-lime-300">
                      2.1 kWh
                    </div>
                    <span className="text-[10px] font-mono text-lime-400/80">Solar Direct Drive</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#061209] border border-emerald-500/20">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Crop Health</span>
                    </div>
                    <div className="text-2xl font-display font-bold text-emerald-300">
                      94%
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400/80">NDVI Vigor Standard</span>
                  </div>
                </div>
              </div>

              {/* Row 3: AI Alert & Recommended Action */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* AI Alert Card */}
                <div className="p-5 rounded-2xl bg-amber-950/40 border border-amber-500/30 flex items-start gap-3.5">
                  <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold block mb-1">
                      AI PREDICTIVE ALERT
                    </span>
                    <p className="text-sm font-semibold text-white">
                      “Rain expected within 18 hours. Irrigation can be delayed.”
                    </p>
                    <span className="text-[11px] text-gray-300 font-light block mt-1">
                      Doppler radar detects 68% rain probability arriving at dawn.
                    </span>
                  </div>
                </div>

                {/* Recommended Action Card */}
                <div className="p-5 rounded-2xl bg-emerald-950/50 border border-lime-400/30 flex items-start gap-3.5">
                  <div className="p-2 rounded-xl bg-lime-400/20 text-lime-400 shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold block mb-1">
                      RECOMMENDED ACTION
                    </span>
                    <p className="text-sm font-bold text-white">
                      “Save 480 L of water.”
                    </p>
                    <span className="text-[11px] text-gray-300 font-light block mt-1">
                      One-click approval schedules automated valve deferral.
                    </span>
                  </div>
                </div>

              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
