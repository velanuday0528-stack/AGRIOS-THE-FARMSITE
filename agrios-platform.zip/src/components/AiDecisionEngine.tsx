import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Cpu, 
  Radio, 
  CloudSun, 
  Satellite, 
  Sprout, 
  BarChart3, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight,
  Droplets,
  Sun,
  PackageCheck
} from 'lucide-react';

export const AiDecisionEngine: React.FC = () => {
  const [selectedDecision, setSelectedDecision] = useState<'water' | 'energy' | 'harvest'>('water');

  const pipelineStages = [
    { label: 'SENSORS', sub: 'Soil & Canopy', icon: Radio },
    { label: 'WEATHER', sub: 'Radar & Wind', icon: CloudSun },
    { label: 'SATELLITE', sub: 'NDVI & Thermal', icon: Satellite },
    { label: 'CROP DATA', sub: 'Phenology Curve', icon: Sprout },
    { label: 'MARKET', sub: 'Price & Demand', icon: BarChart3 },
    { label: 'AGRIOS AI', sub: 'Inference Model', icon: Cpu, isCore: true },
    { label: 'ACTION', sub: 'Valve & Advisory', icon: CheckCircle2, isFinal: true },
  ];

  const decisionDetails = {
    water: {
      category: 'WATER',
      action: 'Delay irrigation',
      icon: Droplets,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/30',
      timing: 'Next 8 Hours',
      rationale: 'Radar shows incoming localized shower within 6 hours. Current soil volumetric tension is within the safe 32% retention threshold. Running pumps now would cause runoff and root leached nitrogen.',
      benefit: 'Saves 1,200 L fresh groundwater + ₹180 pumping power'
    },
    energy: {
      category: 'ENERGY',
      action: 'Use solar surplus',
      icon: Sun,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      timing: 'Peak 1:20 PM Window',
      rationale: 'Photovoltaic inverter output is peaking at 8.4 kW while ambient temperature reaches 34°C. Routing direct DC power into the primary drip manifold creates zero grid import and pre-empts thermal canopy stress.',
      benefit: '100% Zero-Carbon Pumping + 2.1 kWh Saved'
    },
    harvest: {
      category: 'HARVEST',
      action: 'Optimal harvest window in 2 days',
      icon: PackageCheck,
      color: 'text-lime-400',
      bg: 'bg-lime-500/10',
      border: 'border-lime-500/30',
      timing: 'Thursday Morning (6:00 AM)',
      rationale: 'Soluble Brix sugar readings and firmness metrics are at peak Grade-A standards. Terminal mandi wholesale prices are forecasted to crest before weekly supply inflows peak on Friday.',
      benefit: '+14% Premium Realization at Mandi Auction'
    }
  };

  return (
    <section id="decision-engine" className="relative py-28 bg-[#050C07] overflow-hidden">
      {/* Background radial lines */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[550px] bg-emerald-900/15 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute inset-0 bg-tech-grid opacity-25 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Autonomous Inference Pipeline</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            From Data to Decision <span className="text-gradient-emerald">in Seconds.</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            AGRIOS synthesizes multiple real-world inputs through neural agronomic models to produce clear, actionable, high-conviction decisions.
          </p>
        </div>

        {/* Futuristic Flow Pipeline Visual */}
        <div className="mb-16">
          <div className="p-6 sm:p-8 rounded-3xl bg-[#08170F]/80 border border-emerald-500/25 backdrop-blur-2xl shadow-2xl relative">
            <div className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold mb-6 flex items-center justify-between">
              <span>AGRIOS Neural Pipeline Architecture</span>
              <span className="text-lime-400 font-mono text-[11px]">Telemetry Frequency: 60s Cycle</span>
            </div>

            {/* Pipeline Stage Nodes */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 relative">
              {pipelineStages.map((stage, idx) => {
                const Icon = stage.icon;
                return (
                  <div
                    key={stage.label}
                    className={`p-4 rounded-2xl border text-center transition-all duration-300 relative flex flex-col items-center justify-center ${
                      stage.isCore
                        ? 'bg-gradient-to-b from-lime-950/70 to-emerald-950/70 border-lime-400 ring-2 ring-lime-400/40 shadow-xl shadow-lime-950/40'
                        : stage.isFinal
                        ? 'bg-emerald-950/50 border-emerald-400/50'
                        : 'bg-[#051108]/90 border-emerald-500/20'
                    }`}
                  >
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${
                      stage.isCore ? 'bg-lime-400 text-black' : 'bg-emerald-500/10 text-emerald-300'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>

                    <span className="font-mono text-xs font-bold text-white tracking-wider">
                      {stage.label}
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono mt-0.5">
                      {stage.sub}
                    </span>

                    {/* Arrow connector between stages on desktop */}
                    {idx < pipelineStages.length - 1 && (
                      <div className="hidden lg:block absolute -right-2 top-1/2 -translate-y-1/2 z-20 text-emerald-500/60">
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 3 AI Decision Cards */}
        <div>
          <div className="text-center mb-8">
            <span className="text-xs font-mono uppercase tracking-widest text-gray-400 font-semibold">
              Select An Active AI Recommendation Vector
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Card 1: WATER */}
            <div
              onClick={() => setSelectedDecision('water')}
              className={`cursor-pointer p-7 rounded-3xl border transition-all duration-300 backdrop-blur-2xl relative overflow-hidden ${
                selectedDecision === 'water'
                  ? 'bg-[#081D14] border-cyan-400 ring-2 ring-cyan-400/30 shadow-2xl shadow-cyan-950/40 scale-[1.02]'
                  : 'bg-[#07150C]/70 border-emerald-500/20 hover:border-cyan-500/50 hover:bg-[#08180E]'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase">
                  WATER DECISION
                </span>
                <span className="text-[10px] font-mono bg-cyan-950/80 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-500/30">
                  {decisionDetails.water.timing}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 w-fit text-cyan-400 mb-3">
                <Droplets className="w-6 h-6" />
              </div>

              <h3 className="font-display text-2xl font-black text-white mb-2">
                “{decisionDetails.water.action}”
              </h3>

              <p className="text-xs text-gray-300 font-light leading-relaxed mb-4">
                {decisionDetails.water.rationale}
              </p>

              <div className="pt-3 border-t border-cyan-500/20 text-xs font-mono text-cyan-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>{decisionDetails.water.benefit}</span>
              </div>
            </div>

            {/* Card 2: ENERGY */}
            <div
              onClick={() => setSelectedDecision('energy')}
              className={`cursor-pointer p-7 rounded-3xl border transition-all duration-300 backdrop-blur-2xl relative overflow-hidden ${
                selectedDecision === 'energy'
                  ? 'bg-[#18190B] border-amber-400 ring-2 ring-amber-400/30 shadow-2xl shadow-amber-950/40 scale-[1.02]'
                  : 'bg-[#07150C]/70 border-emerald-500/20 hover:border-amber-500/50 hover:bg-[#08180E]'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono font-bold tracking-widest text-amber-400 uppercase">
                  ENERGY DECISION
                </span>
                <span className="text-[10px] font-mono bg-amber-950/80 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
                  {decisionDetails.energy.timing}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 w-fit text-amber-400 mb-3">
                <Sun className="w-6 h-6" />
              </div>

              <h3 className="font-display text-2xl font-black text-white mb-2">
                “{decisionDetails.energy.action}”
              </h3>

              <p className="text-xs text-gray-300 font-light leading-relaxed mb-4">
                {decisionDetails.energy.rationale}
              </p>

              <div className="pt-3 border-t border-amber-500/20 text-xs font-mono text-amber-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{decisionDetails.energy.benefit}</span>
              </div>
            </div>

            {/* Card 3: HARVEST */}
            <div
              onClick={() => setSelectedDecision('harvest')}
              className={`cursor-pointer p-7 rounded-3xl border transition-all duration-300 backdrop-blur-2xl relative overflow-hidden ${
                selectedDecision === 'harvest'
                  ? 'bg-[#0D1D0E] border-lime-400 ring-2 ring-lime-400/30 shadow-2xl shadow-lime-950/40 scale-[1.02]'
                  : 'bg-[#07150C]/70 border-emerald-500/20 hover:border-lime-500/50 hover:bg-[#08180E]'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono font-bold tracking-widest text-lime-400 uppercase">
                  HARVEST DECISION
                </span>
                <span className="text-[10px] font-mono bg-lime-950/80 text-lime-300 px-2 py-0.5 rounded-full border border-lime-500/30">
                  {decisionDetails.harvest.timing}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-lime-500/10 border border-lime-500/30 w-fit text-lime-400 mb-3">
                <PackageCheck className="w-6 h-6" />
              </div>

              <h3 className="font-display text-2xl font-black text-white mb-2">
                “{decisionDetails.harvest.action}”
              </h3>

              <p className="text-xs text-gray-300 font-light leading-relaxed mb-4">
                {decisionDetails.harvest.rationale}
              </p>

              <div className="pt-3 border-t border-lime-500/20 text-xs font-mono text-lime-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-lime-400 shrink-0" />
                <span>{decisionDetails.harvest.benefit}</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
