import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Sprout, 
  Droplets, 
  Activity, 
  Wheat, 
  Snowflake, 
  Truck, 
  Coins, 
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const FarmToMarket: React.FC = () => {
  const [activeStep, setActiveStep] = useState(3); // Harvest by default

  const journeySteps = [
    {
      id: 'seed',
      title: 'SEED',
      sub: 'Varietal selection',
      icon: Sprout,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      detail: 'Soil salinity and historic rainfall models recommend optimal seed genetics.'
    },
    {
      id: 'grow',
      title: 'GROW',
      sub: 'Autonomous Drip',
      icon: Droplets,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      detail: 'Precision root-zone fertigation ensures continuous vegetative vigor.'
    },
    {
      id: 'monitor',
      title: 'MONITOR',
      sub: 'Canopy Telemetry',
      icon: Activity,
      color: 'text-lime-400',
      bg: 'bg-lime-500/10',
      detail: 'Spectral NDVI and thermal infrared sensors detect pest stress 48 hours early.'
    },
    {
      id: 'harvest',
      title: 'HARVEST',
      sub: 'Peak Brix Timing',
      icon: Wheat,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10',
      detail: 'Water cut-off optimization maximizes sugar concentration and shelf firmness.'
    },
    {
      id: 'store',
      title: 'STORE',
      sub: 'Micro-Cold Chain',
      icon: Snowflake,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10',
      detail: 'Solar-powered cold storage telemetry keeps post-harvest respiration near zero.'
    },
    {
      id: 'move',
      title: 'MOVE',
      sub: 'Traceable Transit',
      icon: Truck,
      color: 'text-indigo-400',
      bg: 'bg-indigo-500/10',
      detail: 'Temperature-monitored direct route dispatch straight to processing centers.'
    },
    {
      id: 'market',
      title: 'MARKET',
      sub: 'Grade-A Premium',
      icon: Coins,
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10',
      detail: 'Direct Mandi and institutional B2B procurement capturing +18% higher margin.'
    }
  ];

  return (
    <section className="relative py-28 bg-[#060F09] overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-emerald-950/20 rounded-full blur-[160px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>End-to-End Agri-Value Chain</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            From Soil to Harvest, <span className="text-gradient-emerald">and Beyond.</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            AGRIOS does not stop at irrigation valves. We integrate the entire journey:{' '}
            <strong className="text-white font-medium">Production → Storage → Logistics → Market</strong> to protect farmer margins.
          </p>
        </div>

        {/* 7-Step Interactive Pipeline Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-10">
          {journeySteps.map((step, idx) => {
            const Icon = step.icon;
            const isSelected = activeStep === idx;

            return (
              <button
                key={step.id}
                onClick={() => setActiveStep(idx)}
                className={`p-4 rounded-2xl border text-center transition-all duration-300 flex flex-col items-center justify-between backdrop-blur-xl ${
                  isSelected
                    ? 'bg-[#0E2417] border-lime-400 ring-2 ring-lime-400/40 shadow-xl shadow-lime-950/40 scale-105'
                    : 'bg-[#08150D]/80 border-emerald-500/15 hover:border-emerald-500/40'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${step.bg} border border-white/5`}>
                  <Icon className={`w-5 h-5 ${step.color}`} />
                </div>

                <div>
                  <span className="font-mono text-xs font-bold text-white tracking-wider block">
                    {step.title}
                  </span>
                  <span className="text-[10px] text-gray-400 font-mono mt-0.5 block">
                    {step.sub}
                  </span>
                </div>

                <div className="mt-3 w-2 h-2 rounded-full bg-lime-400 opacity-0 group-hover:opacity-100" />
              </button>
            );
          })}
        </div>

        {/* Selected Step Inspection Card */}
        <div className="max-w-3xl mx-auto">
          <div className="p-6 sm:p-7 rounded-3xl bg-[#091A11]/90 border border-emerald-500/30 backdrop-blur-xl shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="space-y-1">
              <span className="text-[11px] font-mono uppercase tracking-widest text-lime-400 font-bold">
                STAGE 0{activeStep + 1} OF 07 • {journeySteps[activeStep].title}
              </span>
              <h3 className="font-display text-xl font-bold text-white">
                {journeySteps[activeStep].sub}
              </h3>
              <p className="text-xs sm:text-sm text-gray-300 font-light leading-relaxed">
                {journeySteps[activeStep].detail}
              </p>
            </div>

            <div className="shrink-0">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-950 border border-emerald-500/30 font-mono text-xs text-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-lime-400" />
                Integrated Telemetry
              </span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
