import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Sparkles, 
  Globe, 
  MessageSquare, 
  Play,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';
import { FARMER_VOICE_DEMOS } from '../data/mockData';

export const FarmerExperience: React.FC = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<string>('Tamil');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [hasVoiceResponse, setHasVoiceResponse] = useState(true);

  const languages = ['Tamil', 'Hindi', 'Telugu', 'Kannada', 'Marathi', 'English'];
  const currentDemo = FARMER_VOICE_DEMOS[selectedLanguage] || FARMER_VOICE_DEMOS['English'];

  const playVoiceAudio = () => {
    setIsPlayingAudio(true);

    // Use Web Speech API if supported in browser for real speech playback
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(currentDemo.response.replace(/[“”—]/g, ''));
      utterance.rate = 0.95;
      
      // Set language code if available
      const langCodes: Record<string, string> = {
        Tamil: 'ta-IN',
        Hindi: 'hi-IN',
        Telugu: 'te-IN',
        Kannada: 'kn-IN',
        Marathi: 'mr-IN',
        English: 'en-US'
      };
      if (langCodes[selectedLanguage]) {
        utterance.lang = langCodes[selectedLanguage];
      }

      utterance.onend = () => {
        setIsPlayingAudio(false);
      };
      utterance.onerror = () => {
        setIsPlayingAudio(false);
      };

      window.speechSynthesis.speak(utterance);
    } else {
      // Fallback timer simulation
      setTimeout(() => {
        setIsPlayingAudio(false);
      }, 4000);
    }
  };

  const stopVoiceAudio = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
  };

  return (
    <section id="farmer-experience" className="relative py-28 bg-[#040A06] overflow-hidden">
      {/* Ambient background blur */}
      <div className="absolute top-1/2 left-1/4 w-[600px] h-[600px] bg-emerald-950/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute inset-0 bg-dot-grid opacity-20 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Smartphone className="w-3.5 h-3.5" />
            <span>Inclusive Voice-First Technology</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Powerful AI. <span className="text-gradient-emerald">Simple for the Farmer.</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            No complex charts needed in the field. Farmers can simply speak in their mother tongue over WhatsApp or the AGRIOS audio assistant to receive instant, dialect-aware guidance.
          </p>
        </div>

        {/* Main Grid: Smartphone Simulator (Center/Left) + Language Selector & Voice Features (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center max-w-5xl mx-auto">
          
          {/* Smartphone Frame (5 cols) */}
          <div className="lg:col-span-6 flex justify-center">
            <div className="relative w-full max-w-[340px] rounded-[42px] bg-[#020503] p-3 shadow-2xl border-4 border-[#1A2E20] ring-1 ring-emerald-500/30">
              
              {/* Dynamic Island / Notch */}
              <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-30 flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-[#0d2214] ml-auto mr-3 border border-emerald-500/30" />
              </div>

              {/* Phone Screen Canvas */}
              <div className="relative rounded-[32px] bg-[#07130B] border border-emerald-500/20 overflow-hidden flex flex-col h-[580px] p-4 text-white">
                
                {/* App Screen Header */}
                <div className="pt-6 pb-3 border-b border-emerald-500/15 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-lime-400 flex items-center justify-center text-black font-bold text-xs">
                      AG
                    </div>
                    <div>
                      <div className="text-xs font-display font-bold text-white">AGRIOS Voice AI</div>
                      <div className="text-[9px] font-mono text-emerald-400 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-pulse" />
                        Online • {selectedLanguage}
                      </div>
                    </div>
                  </div>
                  <Globe className="w-4 h-4 text-gray-400" />
                </div>

                {/* Chat History Flow */}
                <div className="flex-1 overflow-y-auto py-4 space-y-4">
                  
                  {/* Farmer Voice Query (User Bubble) */}
                  <motion.div
                    key={`user-${selectedLanguage}`}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex flex-col items-end space-y-1"
                  >
                    <div className="text-[10px] font-mono text-gray-400 flex items-center gap-1">
                      <span>Farmer</span>
                      <Mic className="w-2.5 h-2.5 text-lime-400" />
                    </div>
                    <div className="bg-emerald-950/80 border border-emerald-500/30 rounded-2xl rounded-tr-sm p-3.5 max-w-[85%] text-xs font-medium text-emerald-100 shadow-lg">
                      {currentDemo.query}
                    </div>
                  </motion.div>

                  {/* AI Response (AGRIOS Bubble) */}
                  <motion.div
                    key={`ai-${selectedLanguage}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.15 }}
                    className="flex flex-col items-start space-y-1"
                  >
                    <div className="text-[10px] font-mono text-lime-400 flex items-center gap-1 font-semibold">
                      <Sparkles className="w-2.5 h-2.5" />
                      <span>AGRIOS Voice Guidance</span>
                    </div>
                    <div className="bg-[#0B2114] border border-lime-400/30 rounded-2xl rounded-tl-sm p-3.5 max-w-[90%] text-xs text-gray-200 leading-relaxed shadow-lg">
                      {currentDemo.response}

                      {/* Interactive Audio Player inside Message */}
                      <div className="mt-3 pt-2.5 border-t border-emerald-500/20 flex items-center justify-between">
                        <button
                          onClick={isPlayingAudio ? stopVoiceAudio : playVoiceAudio}
                          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-lime-400 text-black font-bold text-[10px] hover:bg-lime-300 transition-colors shadow"
                        >
                          {isPlayingAudio ? (
                            <>
                              <VolumeX className="w-3 h-3" />
                              <span>Stop</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3 h-3" />
                              <span>Listen Audio</span>
                            </>
                          )}
                        </button>

                        {/* Animated Sound Waveform Indicator */}
                        <div className="flex items-center gap-1 h-4">
                          {[40, 70, 90, 60, 100, 50, 80].map((h, i) => (
                            <span
                              key={i}
                              style={{
                                height: isPlayingAudio ? `${h}%` : '20%',
                                transition: 'height 0.15s ease'
                              }}
                              className={`w-1 rounded-full ${
                                isPlayingAudio ? 'bg-lime-400' : 'bg-emerald-800'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>

                </div>

                {/* Bottom Voice Input Bar */}
                <div className="p-3 bg-[#030905] rounded-2xl border border-emerald-500/20 flex items-center justify-between">
                  <div className="text-xs text-gray-400 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-lime-400" />
                    <span>Tap mic to speak in {selectedLanguage}...</span>
                  </div>

                  <button
                    onClick={isPlayingAudio ? stopVoiceAudio : playVoiceAudio}
                    className="w-10 h-10 rounded-full bg-gradient-to-tr from-lime-400 to-emerald-400 text-black flex items-center justify-center shadow-lg shadow-lime-400/30 hover:scale-105 active:scale-95 transition-transform"
                  >
                    <Mic className="w-5 h-5" />
                  </button>
                </div>

              </div>
            </div>
          </div>

          {/* Right Column: Multi-Language Selector & Accessibility Highlights (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                DIALECT & MOTHER-TONGUE ACCESSIBILITY
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white mt-1">
                Zero literacy barrier. 100% agronomic clarity.
              </h3>
              <p className="text-sm text-gray-300 font-light mt-2 leading-relaxed">
                Click any regional language to test how AGRIOS understands colloquial farming vernacular and delivers clear audio instructions:
              </p>
            </div>

            {/* Language Switcher Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {languages.map((lang) => {
                const isSelected = selectedLanguage === lang;
                return (
                  <button
                    key={lang}
                    onClick={() => {
                      setSelectedLanguage(lang);
                      stopVoiceAudio();
                    }}
                    className={`py-3 px-4 rounded-xl border text-sm font-semibold transition-all duration-200 flex items-center justify-between ${
                      isSelected
                        ? 'bg-lime-400 text-black border-lime-300 shadow-lg shadow-lime-400/20 font-bold'
                        : 'bg-[#08170E] text-gray-300 border-emerald-500/20 hover:border-emerald-500/50 hover:bg-[#0B2114]'
                    }`}
                  >
                    <span>{lang}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-black" />}
                  </button>
                );
              })}
            </div>

            {/* 3 Core Inclusive Features */}
            <div className="space-y-3 pt-2">
              <div className="p-4 rounded-2xl bg-[#08170E]/80 border border-emerald-500/20 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-lime-400/10 border border-lime-400/30 text-lime-400 shrink-0">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Voice-First Acoustic Models</h4>
                  <p className="text-xs text-gray-300 font-light mt-0.5">
                    Trained on rural background noise, wind, pump hums, and regional conversational idioms.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#08170E]/80 border border-emerald-500/20 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-cyan-400/10 border border-cyan-400/30 text-cyan-400 shrink-0">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Automated Audio Read-Out</h4>
                  <p className="text-xs text-gray-300 font-light mt-0.5">
                    Farmers don't need to read SMS or long dashboards; AGRIOS speaks the exact minute-by-minute action plan.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#08170E]/80 border border-emerald-500/20 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-400 shrink-0">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">WhatsApp & SMS Integration Ready</h4>
                  <p className="text-xs text-gray-300 font-light mt-0.5">
                    Works over simple WhatsApp voice notes or two-way interactive voice calls (IVR).
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
