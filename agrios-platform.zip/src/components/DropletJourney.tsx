import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Droplet, 
  CloudRain, 
  Database, 
  Layers, 
  GitFork, 
  Sprout, 
  ShoppingBag, 
  ArrowRight, 
  RotateCcw, 
  Sparkles, 
  CheckCircle2, 
  Zap, 
  Coins 
} from 'lucide-react';
import { DROPLET_MILESTONES } from '../data/mockData';

export const DropletJourney: React.FC = () => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isJourneyComplete, setIsJourneyComplete] = useState(false);

  const stepIcons = [CloudRain, Database, Layers, GitFork, Sprout, ShoppingBag];
  const currentMilestone = DROPLET_MILESTONES[currentStepIndex];

  const handleNextStep = () => {
    if (currentStepIndex < DROPLET_MILESTONES.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      setIsJourneyComplete(true);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
    setIsJourneyComplete(false);
  };

  return (
    <section id="droplet-journey" className="relative py-28 bg-[#040C07] overflow-hidden">
      {/* Background cyan/emerald ambient aura */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[550px] bg-cyan-950/20 rounded-full blur-[170px] pointer-events-none" />
      <div className="absolute inset-0 bg-dot-grid opacity-20 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Signature Interactive Experience</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Where Does Your Farm’s <span className="text-gradient-emerald">Next Litre Go?</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            Click the glowing water droplet to track its journey through every layer of the agricultural ecosystem. Discover how AGRIOS converts a single unit of moisture into maximum financial value.
          </p>
        </div>

        {/* Central Interactive Droplet Journey Visual */}
        <div className="max-w-4xl mx-auto bg-[#07170E]/85 border-2 border-emerald-500/35 rounded-3xl p-6 sm:p-10 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
          
          {/* Header Bar */}
          <div className="flex flex-wrap items-center justify-between pb-6 border-b border-emerald-500/15 gap-4">
            <div className="flex items-center gap-3">
              {/* Clickable Glowing Hero Droplet */}
              <motion.button
                onClick={handleNextStep}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                animate={{
                  boxShadow: [
                    '0 0 15px rgba(6, 182, 212, 0.4)',
                    '0 0 35px rgba(16, 185, 129, 0.6)',
                    '0 0 15px rgba(6, 182, 212, 0.4)'
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 via-emerald-400 to-lime-400 text-black flex items-center justify-center cursor-pointer shadow-lg relative group"
                title="Click to advance the droplet"
              >
                <Droplet className="w-6 h-6 fill-current text-[#021008]" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full animate-ping" />
              </motion.button>

              <div>
                <span className="text-[11px] font-mono text-gray-400 uppercase tracking-widest block">
                  Click Droplet or Step To Advance
                </span>
                <span className="text-sm font-bold text-white flex items-center gap-1.5">
                  Stage {currentStepIndex + 1} of 6:
                  <span className="text-lime-300 font-display">
                    {currentMilestone.title}
                  </span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleReset}
                className="px-3 py-1.5 rounded-xl border border-white/10 hover:border-emerald-500/40 text-xs font-mono text-gray-400 hover:text-white transition-colors flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>

              <button
                onClick={handleNextStep}
                className="px-4 py-1.5 rounded-xl bg-lime-400 text-black font-bold text-xs flex items-center gap-1.5 hover:bg-lime-300 transition-all shadow-md shadow-lime-400/20"
              >
                <span>{currentStepIndex === DROPLET_MILESTONES.length - 1 ? 'Finish' : 'Next Stage'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Stepper Progress Bar across 6 milestones */}
          <div className="py-8">
            <div className="grid grid-cols-6 gap-2 relative">
              {DROPLET_MILESTONES.map((ms, idx) => {
                const IconComponent = stepIcons[idx];
                const isActive = currentStepIndex === idx;
                const isPassed = currentStepIndex > idx;

                return (
                  <button
                    key={ms.id}
                    onClick={() => setCurrentStepIndex(idx)}
                    className={`flex flex-col items-center text-center p-2 rounded-xl transition-all duration-300 relative ${
                      isActive
                        ? 'bg-cyan-500/20 border border-cyan-400/60 ring-2 ring-cyan-400/40 scale-105 shadow-lg'
                        : isPassed
                        ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-300'
                        : 'bg-[#051108]/60 border border-white/5 text-gray-500 hover:text-gray-300'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-1 ${
                      isActive ? 'bg-cyan-400 text-black' : isPassed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5'
                    }`}>
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-mono font-bold tracking-tight line-clamp-1">
                      {ms.title.split(' ')[0]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stage Inspection Details Box */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentMilestone.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="rounded-2xl bg-[#040F08]/90 border border-emerald-500/30 p-6 sm:p-8 space-y-6"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold">
                    MILESTONE {currentStepIndex + 1}
                  </span>
                  <h3 className="font-display text-2xl sm:text-3xl font-black text-white mt-0.5">
                    {currentMilestone.title}
                  </h3>
                  <p className="text-xs text-lime-300 font-mono mt-0.5">
                    {currentMilestone.subtitle}
                  </p>
                </div>

                <div className="px-3.5 py-1.5 rounded-full bg-emerald-950 border border-emerald-500/30 font-mono text-xs text-emerald-300 font-semibold">
                  {currentMilestone.efficiencyGain}
                </div>
              </div>

              {/* 4 Required Quantitative Values for Each Stage */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-[#08170E] border border-cyan-500/20">
                  <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">
                    Water Used
                  </span>
                  <span className="text-sm sm:text-base font-display font-bold text-cyan-300">
                    {currentMilestone.waterUsed}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#08170E] border border-emerald-500/20">
                  <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">
                    Water Saved
                  </span>
                  <span className="text-sm sm:text-base font-display font-bold text-emerald-400">
                    {currentMilestone.waterSaved}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#08170E] border border-amber-500/20">
                  <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">
                    Energy Required
                  </span>
                  <span className="text-sm sm:text-base font-display font-bold text-amber-300">
                    {currentMilestone.energyRequired}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#08170E] border border-lime-500/20">
                  <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">
                    Expected Crop Value
                  </span>
                  <span className="text-sm sm:text-base font-display font-bold text-lime-300">
                    {currentMilestone.expectedCropValue}
                  </span>
                </div>
              </div>

              {/* Explanatory Narrative */}
              <p className="text-xs sm:text-sm text-gray-300 font-light leading-relaxed">
                {currentMilestone.detail}
              </p>
            </motion.div>
          </AnimatePresence>

          {/* Grand Signature Takeaway Banner */}
          <div className="mt-8 pt-6 border-t border-emerald-500/20 text-center">
            <h4 className="font-display text-lg sm:text-xl font-bold text-white">
              “AGRIOS calculates the{' '}
              <span className="text-gradient-emerald">highest-value path</span> for every resource.”
            </h4>
            <p className="text-xs text-gray-400 font-mono mt-1">
              Zero guesswork. Maximum yield return per drop and kilowatt.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
