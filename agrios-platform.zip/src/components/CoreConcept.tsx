import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Droplets, Zap, Sprout, Package, Coins, Cpu, CheckCircle2, ArrowRight } from 'lucide-react';

export const CoreConcept: React.FC = () => {
  const [activeNode, setActiveNode] = useState<number>(0);

  const nodes = [
    {
      id: 'water',
      title: 'WATER',
      icon: Droplets,
      color: 'text-cyan-400',
      border: 'border-cyan-500/40',
      bg: 'bg-cyan-500/10',
      glow: 'shadow-cyan-500/20',
      tagline: 'Deficit-Aware Precision Drip',
      metric: '30% Reduction in Water Use',
      description: 'Dynamic soil moisture thresholds adjust in real-time against evapotranspiration models, ensuring zero run-off and zero over-saturation.'
    },
    {
      id: 'energy',
      title: 'ENERGY',
      icon: Zap,
      color: 'text-amber-400',
      border: 'border-amber-500/40',
      bg: 'bg-amber-500/10',
      glow: 'shadow-amber-500/20',
      tagline: 'Solar Surplus Synchronization',
      metric: '25% Pumping Energy Reduction',
      description: 'Irrigation pumps ramp up specifically during peak photovoltaic solar generation curves, preventing expensive grid consumption or diesel usage.'
    },
    {
      id: 'crop-health',
      title: 'CROP HEALTH',
      icon: Sprout,
      color: 'text-emerald-400',
      border: 'border-emerald-500/40',
      bg: 'bg-emerald-500/10',
      glow: 'shadow-emerald-500/20',
      tagline: 'Micro-Climate Stress Defense',
      metric: '94% Median Crop Vigor Index',
      description: 'Continuous VPD (Vapor Pressure Deficit) and thermal canopy tracking identify plant stress 48 hours before visible leaf wilting occurs.'
    },
    {
      id: 'harvest',
      title: 'HARVEST',
      icon: Package,
      color: 'text-lime-400',
      border: 'border-lime-500/40',
      bg: 'bg-lime-500/10',
      glow: 'shadow-lime-500/20',
      tagline: 'Yield Quality Optimization',
      metric: '20% Lower Post-Harvest Loss',
      description: 'Precision water cut-off schedules prior to harvesting concentrate natural sugars and shelf-life firmness for premium Grade-A crops.'
    },
    {
      id: 'value',
      title: 'VALUE',
      icon: Coins,
      color: 'text-yellow-400',
      border: 'border-yellow-500/40',
      bg: 'bg-yellow-500/10',
      glow: 'shadow-yellow-500/20',
      tagline: 'Net Economic Farm Realization',
      metric: '+₹38,000 / Acre Net Margin',
      description: 'Converts agronomic input savings into maximized economic profit by correlating market supply-demand rates with harvest timing.'
    }
  ];

  return (
    <section id="core-concept" className="relative py-28 bg-[#060F09] overflow-hidden">
      {/* Background Ambient Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-emerald-950/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute inset-0 bg-dot-grid opacity-25 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Cpu className="w-3.5 h-3.5" />
            <span>Unified Decision Architecture</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Your Farm. <span className="text-gradient-emerald">Now With Intelligence.</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light leading-relaxed">
            AGRIOS is not simply an automated timer or irrigation switch.{' '}
            <strong className="text-white font-medium">It continuously analyses farm conditions, weather, crop requirements and resource availability</strong> to recommend the highest-value action across every acre.
          </p>
        </div>

        {/* Central Intelligence Node Graph with SVG Animated Connectors */}
        <div className="relative max-w-4xl mx-auto mb-16">
          
          {/* Circular SVG Lines connecting nodes to center */}
          <div className="relative aspect-square max-w-[580px] mx-auto flex items-center justify-center">
            
            {/* SVG Connecting Tracks */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
              <defs>
                <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#10B981" stopOpacity="0.8" />
                  <stop offset="50%" stopColor="#84CC16" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#EAB308" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Concentric orbital rings */}
              <circle
                cx="50%"
                cy="50%"
                r="40%"
                fill="none"
                stroke="rgba(16, 185, 129, 0.12)"
                strokeWidth="1.5"
                strokeDasharray="4 6"
              />
              <circle
                cx="50%"
                cy="50%"
                r="25%"
                fill="none"
                stroke="rgba(132, 204, 22, 0.08)"
                strokeWidth="1"
              />

              {/* Connecting animated energy lines to 5 equidistant nodes (72 deg apart) */}
              {[0, 72, 144, 216, 288].map((angle, i) => {
                const rad = ((angle - 90) * Math.PI) / 180;
                const x2 = 50 + 40 * Math.cos(rad);
                const y2 = 50 + 40 * Math.sin(rad);

                return (
                  <g key={i}>
                    {/* Background line */}
                    <line
                      x1="50%"
                      y1="50%"
                      x2={`${x2}%`}
                      y2={`${y2}%`}
                      stroke="rgba(16, 185, 129, 0.2)"
                      strokeWidth="2"
                    />
                    {/* Animated pulsed beam */}
                    <line
                      x1="50%"
                      y1="50%"
                      x2={`${x2}%`}
                      y2={`${y2}%`}
                      stroke={activeNode === i ? '#84CC16' : 'rgba(52, 211, 153, 0.6)'}
                      strokeWidth={activeNode === i ? '2.5' : '1.5'}
                      className="animate-stream-line"
                    />
                  </g>
                );
              })}
            </svg>

            {/* Central AGRIOS AI ENGINE */}
            <motion.div
              animate={{
                scale: [1, 1.04, 1],
                boxShadow: [
                  '0 0 30px rgba(16, 185, 129, 0.2)',
                  '0 0 60px rgba(132, 204, 22, 0.35)',
                  '0 0 30px rgba(16, 185, 129, 0.2)'
                ]
              }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="relative z-20 w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-gradient-to-b from-[#0F291B] to-[#08150E] border-2 border-lime-400/50 p-1 flex items-center justify-center text-center shadow-2xl"
            >
              <div className="w-full h-full rounded-full bg-[#06120A]/90 backdrop-blur-md flex flex-col items-center justify-center p-3 relative overflow-hidden">
                <div className="absolute inset-0 bg-radial-gradient-hero opacity-80" />
                <div className="p-2 rounded-xl bg-lime-500/10 border border-lime-500/30 text-lime-400 mb-1">
                  <Cpu className="w-6 h-6 animate-pulse" />
                </div>
                <span className="font-display font-black text-xs sm:text-sm tracking-wider text-white">
                  AGRIOS
                </span>
                <span className="text-[10px] font-mono tracking-widest text-lime-400 font-semibold uppercase">
                  AI ENGINE
                </span>
                <span className="text-[9px] text-gray-400 font-mono mt-0.5">
                  Autonomous Core
                </span>
              </div>
            </motion.div>

            {/* 5 Interconnected Resource Nodes arranged on circle */}
            {nodes.map((node, index) => {
              const angle = index * 72 - 90;
              const rad = (angle * Math.PI) / 180;
              // Coordinates on 40% radius of container
              const leftPercent = 50 + 40 * Math.cos(rad);
              const topPercent = 50 + 40 * Math.sin(rad);
              const Icon = node.icon;
              const isSelected = activeNode === index;

              return (
                <button
                  key={node.id}
                  onClick={() => setActiveNode(index)}
                  style={{
                    left: `${leftPercent}%`,
                    top: `${topPercent}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                  className={`absolute z-30 group transition-all duration-300 p-2 sm:p-3 rounded-2xl border backdrop-blur-xl flex flex-col items-center ${
                    isSelected
                      ? `${node.bg} ${node.border} ring-2 ring-lime-400 shadow-xl ${node.glow} scale-110`
                      : 'bg-[#0B1A11]/85 border-emerald-500/20 hover:border-emerald-500/50 hover:scale-105'
                  }`}
                >
                  <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center mb-1 ${node.bg} border ${node.border}`}>
                    <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${node.color}`} />
                  </div>
                  <span className="font-display font-bold text-[11px] sm:text-xs text-white tracking-wide">
                    {node.title}
                  </span>
                  <span className="text-[9px] font-mono text-gray-400 hidden sm:block">
                    {node.tagline.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Detail Card for Active Node */}
        <div className="max-w-2xl mx-auto">
          <div className="p-6 rounded-2xl bg-[#09170E]/90 border border-emerald-500/30 backdrop-blur-xl shadow-2xl relative overflow-hidden">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-emerald-500/15">
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-xl ${nodes[activeNode].bg} border ${nodes[activeNode].border}`}>
                  {React.createElement(nodes[activeNode].icon, { className: `w-6 h-6 ${nodes[activeNode].color}` })}
                </div>
                <div>
                  <div className="text-xs font-mono uppercase tracking-wider text-gray-400">
                    Active Optimization Vector
                  </div>
                  <h3 className="font-display text-xl font-bold text-white flex items-center gap-2">
                    {nodes[activeNode].title}
                    <span className="text-xs font-mono text-lime-400 bg-lime-950/60 px-2 py-0.5 rounded-full border border-lime-500/30">
                      {nodes[activeNode].tagline}
                    </span>
                  </h3>
                </div>
              </div>

              <div className="px-3.5 py-1.5 rounded-xl bg-emerald-950/50 border border-emerald-500/30 font-mono text-xs text-emerald-300 font-semibold">
                {nodes[activeNode].metric}
              </div>
            </div>

            <p className="text-sm text-gray-300 font-light mt-4 leading-relaxed">
              {nodes[activeNode].description}
            </p>

            <div className="mt-4 pt-3 flex items-center justify-between text-xs font-mono text-emerald-400/80">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-lime-400" />
                Interlocked with 4 neighboring vectors
              </span>
              <button
                onClick={() => setActiveNode((activeNode + 1) % nodes.length)}
                className="hover:text-white flex items-center gap-1 transition-colors"
              >
                <span>Inspect Next Node</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
