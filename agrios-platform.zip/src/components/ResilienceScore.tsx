import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Droplets, Zap, Sprout, CloudLightning, PackageCheck, Award } from 'lucide-react';

export const ResilienceScore: React.FC = () => {
  const overallScore = 82;

  const breakdown = [
    { label: 'Water Efficiency', score: 88, icon: Droplets, color: 'text-cyan-400', barColor: 'from-cyan-500 to-blue-400' },
    { label: 'Energy Efficiency', score: 76, icon: Zap, color: 'text-amber-400', barColor: 'from-amber-500 to-yellow-400' },
    { label: 'Crop Health', score: 91, icon: Sprout, color: 'text-emerald-400', barColor: 'from-emerald-500 to-lime-400' },
    { label: 'Climate Readiness', score: 73, icon: CloudLightning, color: 'text-purple-400', barColor: 'from-purple-500 to-indigo-400' },
    { label: 'Post-Harvest Readiness', score: 82, icon: PackageCheck, color: 'text-lime-400', barColor: 'from-lime-500 to-emerald-400' }
  ];

  // SVG Circular Gauge calculation
  const radius = 90;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (overallScore / 100) * circumference;

  return (
    <section className="relative py-28 bg-[#040A06] overflow-hidden">
      {/* Background ambient light */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-emerald-950/25 rounded-full blur-[160px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Award className="w-3.5 h-3.5" />
            <span>Composite Agronomic Health Index</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            AGRIOS Farm <span className="text-gradient-emerald">Resilience Score</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            A single unified index synthesizing water buffering, solar autonomy, disease resistance, and market shelf-life into actionable farm value.
          </p>
        </div>

        {/* Resilience Widget Container (2 Cols) */}
        <div className="max-w-4xl mx-auto bg-[#07170E]/85 border-2 border-emerald-500/30 rounded-3xl p-8 sm:p-12 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center">
            
            {/* Left: Circular SVG Score Gauge (5 cols) */}
            <div className="md:col-span-5 flex flex-col items-center justify-center">
              <div className="relative w-56 h-56 flex items-center justify-center">
                
                {/* SVG Gauge */}
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="112"
                    cy="112"
                    r={radius}
                    stroke="rgba(16, 185, 129, 0.15)"
                    strokeWidth="16"
                    fill="transparent"
                  />
                  <motion.circle
                    cx="112"
                    cy="112"
                    r={radius}
                    stroke="url(#resilienceGradient)"
                    strokeWidth="16"
                    strokeDasharray={circumference}
                    initial={{ strokeDashoffset: circumference }}
                    whileInView={{ strokeDashoffset }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.8, ease: 'easeOut' }}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                  <defs>
                    <linearGradient id="resilienceGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#10B981" />
                      <stop offset="50%" stopColor="#84CC16" />
                      <stop offset="100%" stopColor="#FDE047" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* Score Center Text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <motion.span
                    initial={{ scale: 0.5, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.3 }}
                    className="font-display text-6xl font-black text-white tracking-tight"
                  >
                    {overallScore}
                  </motion.span>
                  <span className="text-[11px] font-mono tracking-widest uppercase text-lime-400 font-bold mt-1">
                    FARM RESILIENCE
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400/80">
                    High Climate Armor
                  </span>
                </div>
              </div>

              <div className="mt-4 text-center">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-lime-950/60 border border-lime-500/30 text-lime-300 text-xs font-mono">
                  <ShieldCheck className="w-3.5 h-3.5 text-lime-400" />
                  Top 8% Regional Tier
                </span>
              </div>
            </div>

            {/* Right: Detailed Metric Breakdown Bars (7 cols) */}
            <div className="md:col-span-7 space-y-4">
              <div className="text-xs font-mono uppercase tracking-widest text-gray-400 font-bold mb-2">
                DIMENSIONAL RESILIENCE BREAKDOWN
              </div>

              {breakdown.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-300 font-medium flex items-center gap-2">
                        <Icon className={`w-3.5 h-3.5 ${item.color}`} />
                        {item.label}
                      </span>
                      <span className="font-mono font-bold text-white text-sm">
                        {item.score} <span className="text-gray-500 text-xs">/100</span>
                      </span>
                    </div>

                    <div className="w-full h-2.5 bg-[#030B06] rounded-full overflow-hidden border border-emerald-500/15">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${item.score}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.2, ease: 'easeOut' }}
                        className={`h-full bg-gradient-to-r ${item.barColor} rounded-full`}
                      />
                    </div>
                  </div>
                );
              })}

              <div className="pt-4 border-t border-emerald-500/15 flex items-center justify-between text-[11px] font-mono text-gray-400">
                <span>Weighted across 24 agronomic sub-indices</span>
                <span className="text-emerald-400">Updated hourly</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
