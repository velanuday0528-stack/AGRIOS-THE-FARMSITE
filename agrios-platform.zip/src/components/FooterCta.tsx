import React from 'react';
import { ArrowRight, Droplets, ShieldCheck, Sparkles, Sprout, Heart } from 'lucide-react';
import { AppView } from '../types';

interface FooterCtaProps {
  setCurrentView: (view: AppView) => void;
  onExploreClick: () => void;
}

export const FooterCta: React.FC<FooterCtaProps> = ({ setCurrentView, onExploreClick }) => {
  return (
    <footer className="relative bg-[#030704] text-white pt-24 pb-12 border-t border-emerald-500/20 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute inset-0 bg-tech-grid opacity-20 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Full-Width High-Impact Statement */}
        <div className="text-center max-w-4xl mx-auto space-y-6 pb-20 border-b border-emerald-500/15">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The New Era of Climate-Resilient Agriculture</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
            “The future of farming isn’t about using more resources.”
            <span className="block mt-2 text-gradient-emerald">
              “It’s about making every resource count.”
            </span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light max-w-2xl mx-auto">
            From single-acre family plots to expansive agricultural cooperatives, AGRIOS delivers the autonomous intelligence layer needed to safeguard yield and water security.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={() => setCurrentView('signup')}
              className="group px-8 py-4 rounded-xl font-bold text-sm text-gray-950 bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 shadow-xl shadow-emerald-500/25 hover:shadow-lime-400/40 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2.5"
            >
              <span>Start with AGRIOS</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onExploreClick}
              className="px-7 py-4 rounded-xl font-semibold text-sm text-white bg-[#0A1A10] hover:bg-emerald-950/80 border border-emerald-500/30 hover:border-emerald-500/60 backdrop-blur-md transition-all hover:text-lime-300 flex items-center gap-2"
            >
              <span>Explore the Intelligence</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Footer Navigation & Brand Section */}
        <div className="pt-16 pb-12 grid grid-cols-1 md:grid-cols-12 gap-10">
          
          {/* Brand Info (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-lime-500 flex items-center justify-center p-0.5 shadow-lg">
                <div className="w-full h-full bg-[#060F09] rounded-[10px] flex items-center justify-center">
                  <Droplets className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
              <span className="font-display font-black text-2xl tracking-wider text-white">
                AGRIOS
              </span>
            </div>

            <p className="text-sm font-display font-bold text-emerald-300">
              Make Every Drop Work. Make Every Crop Count.
            </p>

            <p className="text-xs text-gray-400 font-light leading-relaxed max-w-sm">
              An intelligent decision layer between the farm, its resources, and its future. Precision water, solar synchronization, and predictive agronomic intelligence.
            </p>

            <div className="pt-2 flex items-center gap-2 text-xs font-mono text-emerald-400/80">
              <ShieldCheck className="w-4 h-4 text-lime-400" />
              <span>Patented Closed-Loop Agronomic Optimization Models</span>
            </div>
          </div>

          {/* Quick Links (7 cols) */}
          <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-8">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold block mb-4">
                Platform
              </span>
              <ul className="space-y-2.5 text-xs text-gray-400 font-light">
                <li><button onClick={() => setCurrentView('dashboard')} className="hover:text-white transition-colors">Farm Dashboard</button></li>
                <li><button onClick={onExploreClick} className="hover:text-white transition-colors">AI Decision Engine</button></li>
                <li><button onClick={onExploreClick} className="hover:text-white transition-colors">Spatial Zone Maps</button></li>
                <li><button onClick={onExploreClick} className="hover:text-white transition-colors">Digital Twin Simulator</button></li>
                <li><button onClick={onExploreClick} className="hover:text-white transition-colors">Voice Assistant</button></li>
              </ul>
            </div>

            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold block mb-4">
                Solutions
              </span>
              <ul className="space-y-2.5 text-xs text-gray-400 font-light">
                <li><a href="#zones" className="hover:text-white transition-colors">Drip Irrigation</a></li>
                <li><a href="#zones" className="hover:text-white transition-colors">Solar Synchronization</a></li>
                <li><a href="#zones" className="hover:text-white transition-colors">Crop Stress Defense</a></li>
                <li><a href="#zones" className="hover:text-white transition-colors">Post-Harvest Freshness</a></li>
                <li><a href="#zones" className="hover:text-white transition-colors">Enterprise Co-ops</a></li>
              </ul>
            </div>

            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold block mb-4">
                Access
              </span>
              <ul className="space-y-2.5 text-xs text-gray-400 font-light">
                <li><button onClick={() => setCurrentView('login')} className="hover:text-white text-emerald-300 transition-colors font-medium">Farmer Login →</button></li>
                <li><button onClick={() => setCurrentView('signup')} className="hover:text-white text-lime-300 transition-colors font-medium">Create Farm Profile →</button></li>
                <li><button onClick={() => setCurrentView('dashboard')} className="hover:text-white text-cyan-300 transition-colors font-medium">Live Demo Console →</button></li>
              </ul>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-emerald-500/10 flex flex-col sm:flex-row items-center justify-between text-xs font-mono text-gray-500 gap-4">
          <div>
            © {new Date().getFullYear()} AGRIOS Technologies, Inc. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span className="hover:text-gray-400 cursor-pointer">Privacy & Telemetry Policy</span>
            <span>•</span>
            <span className="hover:text-gray-400 cursor-pointer">Terms of Service</span>
            <span>•</span>
            <span className="hover:text-gray-400 cursor-pointer">Field Validation Target Disclosures</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
