import React, { useState, useEffect } from 'react';
import { Droplets, Sprout, ShieldCheck, Menu, X, ArrowRight, UserCheck, LayoutDashboard } from 'lucide-react';
import { AppView } from '../types';

interface NavbarProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  onNavigateSection?: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, setCurrentView, onNavigateSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    if (currentView !== 'landing') {
      setCurrentView('landing');
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#060F09]/80 backdrop-blur-xl border-b border-emerald-500/20 shadow-2xl shadow-emerald-950/20 py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <div
            onClick={() => setCurrentView('landing')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-lime-500 flex items-center justify-center p-0.5 shadow-lg shadow-emerald-500/25 group-hover:shadow-lime-500/35 transition-all">
              <div className="w-full h-full bg-[#060F09] rounded-[10px] flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-emerald-500/10 group-hover:bg-lime-500/20 transition-colors" />
                <Droplets className="w-5 h-5 text-emerald-400 group-hover:text-lime-300 transition-colors" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display font-bold text-2xl tracking-wider text-white">AGRIOS</span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-lime-400 animate-pulse" />
              </div>
              <span className="text-[10px] tracking-widest uppercase font-mono text-emerald-400/90 font-medium block -mt-1">
                Intelligent Farming
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-[#0A1A10]/60 border border-emerald-500/15 rounded-full px-4 py-1.5 backdrop-blur-md">
            <button
              onClick={() => handleNavClick('hero')}
              className="text-xs uppercase tracking-wider font-semibold text-gray-300 hover:text-lime-300 px-3.5 py-1.5 rounded-full transition-colors hover:bg-emerald-500/10"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('core-concept')}
              className="text-xs uppercase tracking-wider font-semibold text-gray-300 hover:text-lime-300 px-3.5 py-1.5 rounded-full transition-colors hover:bg-emerald-500/10"
            >
              Intelligence
            </button>
            <button
              onClick={() => handleNavClick('zones')}
              className="text-xs uppercase tracking-wider font-semibold text-gray-300 hover:text-lime-300 px-3.5 py-1.5 rounded-full transition-colors hover:bg-emerald-500/10"
            >
              Solutions
            </button>
            <button
              onClick={() => handleNavClick('decision-engine')}
              className="text-xs uppercase tracking-wider font-semibold text-gray-300 hover:text-lime-300 px-3.5 py-1.5 rounded-full transition-colors hover:bg-emerald-500/10"
            >
              How It Works
            </button>
            <button
              onClick={() => handleNavClick('simulator')}
              className="text-xs uppercase tracking-wider font-semibold text-lime-400 hover:text-lime-200 px-3.5 py-1.5 rounded-full transition-colors hover:bg-lime-500/15 flex items-center gap-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-ping" />
              Simulator
            </button>
            <button
              onClick={() => handleNavClick('why-agrios')}
              className="text-xs uppercase tracking-wider font-semibold text-gray-300 hover:text-lime-300 px-3.5 py-1.5 rounded-full transition-colors hover:bg-emerald-500/10"
            >
              Impact
            </button>
          </nav>

          {/* Action CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            <button
              onClick={() => setCurrentView('login')}
              className="text-xs uppercase tracking-wider font-semibold text-emerald-300 hover:text-white px-4 py-2 rounded-xl transition-all border border-emerald-500/20 hover:border-emerald-500/50 hover:bg-emerald-500/10 flex items-center gap-1.5"
            >
              <UserCheck className="w-3.5 h-3.5 text-lime-400" />
              Farmer Login
            </button>

            <button
              onClick={() => setCurrentView('signup')}
              className="relative group overflow-hidden text-xs uppercase tracking-wider font-bold text-gray-950 px-5 py-2.5 rounded-xl bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 shadow-md shadow-emerald-500/25 hover:shadow-lime-400/40 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </button>

            <button
              onClick={() => setCurrentView('dashboard')}
              title="Quick preview full SaaS dashboard"
              className="text-xs font-semibold text-gray-400 hover:text-white p-2 rounded-xl border border-white/10 hover:border-emerald-400/30 hover:bg-white/5 transition-all"
            >
              <LayoutDashboard className="w-4 h-4 text-emerald-400" />
            </button>
          </div>

          {/* Mobile menu toggle */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setCurrentView('dashboard')}
              className="text-xs font-semibold text-emerald-400 bg-emerald-950/50 border border-emerald-500/30 px-2.5 py-1.5 rounded-lg flex items-center gap-1"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>App</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-[#0E1F16] border border-emerald-500/20 text-emerald-400"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#07130A]/95 border-b border-emerald-500/20 backdrop-blur-2xl px-6 py-6 space-y-4 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col space-y-2">
            <button
              onClick={() => handleNavClick('hero')}
              className="text-left py-2 text-sm font-semibold text-gray-200 hover:text-lime-300"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('core-concept')}
              className="text-left py-2 text-sm font-semibold text-gray-200 hover:text-lime-300"
            >
              Core Intelligence
            </button>
            <button
              onClick={() => handleNavClick('zones')}
              className="text-left py-2 text-sm font-semibold text-gray-200 hover:text-lime-300"
            >
              Smart Resource Zones
            </button>
            <button
              onClick={() => handleNavClick('simulator')}
              className="text-left py-2 text-sm font-semibold text-lime-400 hover:text-lime-200"
            >
              Farm "What-If" Simulator
            </button>
            <button
              onClick={() => handleNavClick('droplet-journey')}
              className="text-left py-2 text-sm font-semibold text-cyan-400 hover:text-cyan-200"
            >
              Where Does Your Litre Go?
            </button>
            <button
              onClick={() => handleNavClick('farmer-experience')}
              className="text-left py-2 text-sm font-semibold text-gray-200 hover:text-lime-300"
            >
              Voice-First Farmer App
            </button>
          </div>

          <div className="pt-4 border-t border-emerald-500/20 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setCurrentView('login');
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 rounded-xl border border-emerald-500/30 text-emerald-300 text-sm font-semibold text-center hover:bg-emerald-500/10"
            >
              Farmer Login
            </button>
            <button
              onClick={() => {
                setCurrentView('signup');
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-lime-400 to-emerald-400 text-gray-950 font-bold text-sm text-center shadow-lg shadow-emerald-500/20"
            >
              Create Farm Account
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
