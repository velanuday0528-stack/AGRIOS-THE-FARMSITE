import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  X, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Bot, 
  User, 
  CornerDownLeft, 
  Droplet,
  CloudRain,
  Sprout,
  HelpCircle,
  Wheat
} from 'lucide-react';
import { ChatMessage } from '../types';

export const AiAssistantModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputQuery, setInputQuery] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'agrios',
      text: 'Vanakkam & Hello! I am AGRIOS AI, your farm’s real-time agronomic copilot. How can I optimize your crop, water, or energy today?',
      timestamp: 'Just now'
    }
  ]);

  const promptSuggestions = [
    { label: 'Should I irrigate today?', icon: Droplet },
    { label: 'How much water do I need?', icon: Droplet },
    { label: 'Is my crop under stress?', icon: Sprout },
    { label: 'When should I harvest?', icon: Wheat },
    { label: 'What will happen if rainfall fails?', icon: CloudRain }
  ];

  const knowledgeAnswers: Record<string, string> = {
    'Should I irrigate today?':
      'Based on today’s Doppler radar and 34% soil moisture, hold off regular drip. There is a 72% rain probability forecast for tomorrow afternoon. Postponing irrigation will save 1,200 L without inducing water stress.',
    'How much water do I need?':
      'Your 2.4-acre tomato and chilli plot requires 420 L today for Zone B only. Zones A, C, and D are within the optimum capillary tension zone.',
    'Is my crop under stress?':
      'Current Crop Vigor Index is at 94% (Optimal). Thermal infrared canopy sensors show no stomatal closure. However, ambient temperature will reach 37°C in 3 days, so a pre-cooling solar misting cycle has been scheduled.',
    'When should I harvest?':
      'Your Zone A Tomato fruit has reached 5.8° Brix sugar concentration. The optimal harvest window opens Thursday morning at 6:00 AM before afternoon heat softens firmness.',
    'What will happen if rainfall fails?':
      'AGRIOS digital twin has pre-buffered 14,000 L in your ultrasonic covered reservoir. If rainfall fails completely, deficit irrigation mode will safely sustain crops for 9 consecutive days with zero yield penalty.'
  };

  const handleSendMessage = (queryText: string) => {
    const trimmed = queryText.trim();
    if (!trimmed) return;

    // Add user message
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'farmer',
      text: trimmed,
      timestamp: 'Now'
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');

    // Generate intelligent AI answer
    setTimeout(() => {
      let replyText = knowledgeAnswers[trimmed];
      if (!replyText) {
        replyText = `Analyzing real-time telemetry for "${trimmed}"... Sensors indicate soil moisture at 34%, canopy temperature at 29°C, and 8.4 kWh solar capacity. AGRIOS recommends maintaining current automated cycles while conserving 480 L for predicted weather shifts.`;
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'agrios',
        text: replyText,
        timestamp: 'Just now'
      };

      setMessages((prev) => [...prev, aiMsg]);
    }, 600);
  };

  const handleVoiceToggle = () => {
    if (isRecording) {
      setIsRecording(false);
      handleSendMessage('Should I irrigate today?');
    } else {
      setIsRecording(true);
      // Simulate listening for 2 seconds
      setTimeout(() => {
        setIsRecording(false);
        handleSendMessage('Should I irrigate today?');
      }, 2500);
    }
  };

  const playSpeech = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);
      setIsPlayingAudio(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-5 py-3.5 rounded-full bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 text-gray-950 font-display font-extrabold text-sm shadow-2xl shadow-emerald-500/40 border border-lime-300/60 hover:shadow-lime-400/50 transition-all"
      >
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gray-950 opacity-75" />
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-gray-950" />
        </span>
        <Sparkles className="w-4 h-4 text-gray-950" />
        <span>Ask AGRIOS</span>
      </motion.button>

      {/* Slide-in Modal Drawer */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 40, scale: 0.95 }}
              transition={{ duration: 0.25 }}
              className="w-full sm:max-w-xl bg-[#07150C] border-2 border-emerald-500/40 rounded-t-[32px] sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[640px] max-h-[90vh] text-white"
            >
              {/* Header */}
              <div className="p-4 sm:p-5 border-b border-emerald-500/20 bg-[#0A1F13] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-lime-400 to-emerald-400 text-black flex items-center justify-center font-bold">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
                      Ask AGRIOS
                      <span className="text-[10px] font-mono bg-lime-950 text-lime-300 px-2 py-0.5 rounded-full border border-lime-500/30">
                        Autonomous Copilot
                      </span>
                    </h3>
                    <p className="text-xs text-gray-400 font-mono">
                      Voice & Natural Language Telemetry
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setIsOpen(false);
                    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
                  }}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Chat Messages Flow */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                {messages.map((msg) => {
                  const isUser = msg.sender === 'farmer';
                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      {!isUser && (
                        <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-lime-400 flex items-center justify-center shrink-0 mt-1">
                          <Bot className="w-4 h-4" />
                        </div>
                      )}

                      <div
                        className={`p-4 rounded-2xl max-w-[85%] text-xs sm:text-sm leading-relaxed ${
                          isUser
                            ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 text-white rounded-tr-sm shadow-md'
                            : 'bg-[#0B1E12] border border-emerald-500/25 text-gray-200 rounded-tl-sm shadow-md'
                        }`}
                      >
                        <p>{msg.text}</p>

                        {!isUser && (
                          <div className="mt-2.5 pt-2 border-t border-emerald-500/15 flex items-center justify-between text-[11px] font-mono text-gray-400">
                            <span>{msg.timestamp}</span>
                            <button
                              onClick={() => playSpeech(msg.text)}
                              className="text-lime-400 hover:text-lime-300 flex items-center gap-1 transition-colors"
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>Read Aloud</span>
                            </button>
                          </div>
                        )}
                      </div>

                      {isUser && (
                        <div className="w-7 h-7 rounded-lg bg-lime-400/20 text-lime-300 flex items-center justify-center shrink-0 mt-1">
                          <User className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Prompt Suggestions */}
                <div className="pt-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block mb-2 font-semibold">
                    Quick Agronomic Queries:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {promptSuggestions.map((s) => {
                      const Icon = s.icon;
                      return (
                        <button
                          key={s.label}
                          onClick={() => handleSendMessage(s.label)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#0E2718] border border-emerald-500/25 hover:border-lime-400/50 text-[11px] text-gray-300 hover:text-white transition-all flex items-center gap-1.5"
                        >
                          <Icon className="w-3 h-3 text-lime-400" />
                          <span>{s.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Bottom Input Area */}
              <div className="p-3 sm:p-4 bg-[#051009] border-t border-emerald-500/20">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(inputQuery);
                  }}
                  className="flex items-center gap-2"
                >
                  <button
                    type="button"
                    onClick={handleVoiceToggle}
                    className={`p-2.5 rounded-xl border transition-all ${
                      isRecording
                        ? 'bg-red-500 text-white border-red-400 animate-pulse'
                        : 'bg-[#0A1F13] text-lime-400 border-emerald-500/30 hover:border-lime-400'
                    }`}
                    title={isRecording ? 'Listening...' : 'Voice Input (Click to speak)'}
                  >
                    {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>

                  <input
                    type="text"
                    value={inputQuery}
                    onChange={(e) => setInputQuery(e.target.value)}
                    placeholder={isRecording ? 'Listening to voice...' : 'Ask about water, irrigation, harvest, weather...'}
                    className="flex-1 bg-[#09170E] border border-emerald-500/30 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-gray-500 focus:outline-none focus:border-lime-400"
                  />

                  <button
                    type="submit"
                    className="p-2.5 rounded-xl bg-gradient-to-r from-lime-400 to-emerald-400 text-black font-bold hover:scale-105 active:scale-95 transition-transform"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>

                <div className="mt-2 text-center text-[10px] font-mono text-gray-500">
                  AGRIOS Neural Engine • Multi-lingual • Real-time telemetry grounded
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
