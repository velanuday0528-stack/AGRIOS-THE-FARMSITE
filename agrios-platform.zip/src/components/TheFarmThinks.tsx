import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Clock, 
  CloudRain, 
  Thermometer, 
  Droplet, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  ChevronRight,
  TrendingDown,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { TIMELINE_ITEMS } from '../data/mockData';

export const TheFarmThinks: React.FC = () => {
  const [selectedDayIndex, setSelectedDayIndex] = useState(1); // default to Tomorrow where rain happens

  const decisions = [
    {
      day: 'TODAY',
      action: 'Maintain capillary tension',
      detail: 'Sensors detect 34% volumetric moisture. Soil pore suction is balanced. Hold off midday pumping to reduce evaporation.',
      waterImpact: 'Preserving 350 L in root zone',
      status: 'Normal baseline'
    },
    {
      day: 'TOMORROW',
      action: 'Delay irrigation by 8 hours and reserve 1,200 L for predicted dry conditions.',
      detail: 'Predictive radar models indicate 72% rain probability at 3:00 PM. By postponing irrigation, the crop will absorb 100% natural precipitation with zero leaching.',
      waterImpact: 'Saving 1,200 L freshwater + ₹280 pumping cost',
      status: 'Proactive conservation'
    },
    {
      day: '+3 DAYS',
      action: 'Pre-cool canopy with automated solar misting cycle at 11:30 AM.',
      detail: 'Ambient thermal forecast projects 37°C. Micro-pulsing 180 L via 100% photovoltaic generation prevents stomatal shutdown and heat sunburn.',
      waterImpact: 'Safeguarding +8% tomato fruit firmness',
      status: 'Stress shielding'
    },
    {
      day: '+7 DAYS',
      action: 'Pre-charge reservoir to 95% capacity prior to canal maintenance shutoff.',
      detail: 'Upstream canal telemetry signals 48-hour gate closure. AGRIOS switches pump into solar storage buffer mode to guarantee uninterrupted drip cycles.',
      waterImpact: '100% drought resilience secured',
      status: 'Contingency locked'
    }
  ];

  return (
    <section id="the-farm-thinks" className="relative py-28 bg-[#040A06] overflow-hidden text-white">
      {/* Background radial gradients */}
      <div className="absolute top-1/3 right-0 w-[600px] h-[600px] bg-emerald-900/15 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-900/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute inset-0 bg-tech-grid opacity-20 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Forward-Looking Agronomic Simulation</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold tracking-tight">
            What if your farm could <span className="text-gradient-emerald">think ahead?</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            Traditional farming reacts to yesterday's dry soil. AGRIOS models the next 7 days of climate, soil dynamics, and plant physiology to make <strong className="text-white font-medium">predictive rather than reactive</strong> decisions.
          </p>
        </div>

        {/* Interactive Predictive Timeline Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {TIMELINE_ITEMS.map((item, idx) => {
            const isSelected = selectedDayIndex === idx;
            return (
              <button
                key={item.day}
                onClick={() => setSelectedDayIndex(idx)}
                className={`text-left p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden backdrop-blur-xl ${
                  isSelected
                    ? 'bg-[#0A1F13] border-lime-400/60 shadow-xl shadow-lime-950/40 ring-1 ring-lime-400/40 scale-[1.02]'
                    : 'bg-[#07130B]/70 border-emerald-500/15 hover:border-emerald-500/40 hover:bg-[#091A10]'
                }`}
              >
                {/* Active Indicator Bar */}
                <div
                  className={`absolute top-0 left-0 right-0 h-1 transition-all ${
                    isSelected ? 'bg-gradient-to-r from-lime-400 to-emerald-400' : 'bg-transparent'
                  }`}
                />

                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-xs tracking-wider uppercase font-bold text-gray-400">
                    {item.day}
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                    isSelected ? 'bg-lime-950 text-lime-300 border-lime-500/40' : 'bg-emerald-950/50 text-emerald-400 border-emerald-500/20'
                  }`}>
                    {item.badge}
                  </span>
                </div>

                <div className="text-sm font-bold text-white mb-2">
                  {item.moisture}
                </div>

                <div className="space-y-1 text-xs text-gray-400 font-light">
                  <div className="flex items-center gap-1.5 text-gray-300">
                    <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                    <span>{item.temp}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-gray-300">
                    <CloudRain className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{item.forecast}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-emerald-500/10 flex items-center justify-between text-[11px] font-mono">
                  <span className={isSelected ? 'text-lime-300 font-semibold' : 'text-gray-400'}>
                    {isSelected ? '● Active View' : 'Click to inspect'}
                  </span>
                  <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isSelected ? 'text-lime-400 translate-x-1' : 'text-gray-500'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Highlighted AI Decision Box */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedDayIndex}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3 }}
            className="rounded-3xl bg-gradient-to-r from-[#07180F] via-[#092215] to-[#08180E] border-2 border-emerald-500/40 p-7 sm:p-9 shadow-2xl relative overflow-hidden"
          >
            {/* Top ambient glow */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-lime-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
              
              <div className="lg:col-span-8 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-lime-400/10 border border-lime-400/30 text-lime-400">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                    PREDICTIVE AI DECISION • {decisions[selectedDayIndex].day}
                  </span>
                  <span className="text-xs font-mono text-gray-400 hidden sm:inline">
                    [{decisions[selectedDayIndex].status}]
                  </span>
                </div>

                <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                  “{decisions[selectedDayIndex].action}”
                </h3>

                <p className="text-sm sm:text-base text-gray-300 font-light leading-relaxed">
                  {decisions[selectedDayIndex].detail}
                </p>

                <div className="inline-flex items-center gap-2 text-xs font-mono text-emerald-300 bg-emerald-950/70 border border-emerald-500/30 px-3.5 py-1.5 rounded-xl">
                  <CheckCircle2 className="w-3.5 h-3.5 text-lime-400" />
                  <span>{decisions[selectedDayIndex].waterImpact}</span>
                </div>
              </div>

              {/* Simulation Visual Effect Widget */}
              <div className="lg:col-span-4 bg-[#05110A]/80 border border-emerald-500/25 rounded-2xl p-5 space-y-4">
                <div className="text-xs font-mono uppercase tracking-wider text-gray-400 flex items-center justify-between">
                  <span>Simulation Efficacy</span>
                  <span className="text-lime-400 font-bold">+99.4% Confidence</span>
                </div>

                {/* Graph bars simulation */}
                <div className="space-y-2.5">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-300">Reactive Irrigation</span>
                      <span className="text-red-400 font-mono">-1,200 L Wasted</span>
                    </div>
                    <div className="w-full h-2 bg-black/50 rounded-full overflow-hidden">
                      <div className="h-full bg-red-500/60 rounded-full w-[85%]" />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-300">AGRIOS AI Optimization</span>
                      <span className="text-lime-300 font-mono">+100% Retained</span>
                    </div>
                    <div className="w-full h-2 bg-black/50 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-emerald-500 to-lime-400 rounded-full w-[95%]" />
                    </div>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-gray-400 font-light leading-snug border-t border-emerald-500/10">
                  Calculated against 10-year local microclimate history and real-time radar telemetry.
                </div>
              </div>

            </div>
          </motion.div>
        </AnimatePresence>

      </div>
    </section>
  );
};
