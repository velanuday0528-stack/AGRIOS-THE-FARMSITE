import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Sun, 
  Zap, 
  Droplets, 
  Sprout, 
  Package, 
  ArrowRight, 
  Play, 
  Activity, 
  ShieldCheck, 
  TrendingUp, 
  Cpu,
  Layers,
  Sparkles
} from 'lucide-react';
import { AppView } from '../types';

interface HeroProps {
  setCurrentView: (view: AppView) => void;
  onExploreClick: () => void;
  onHowItWorksClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ setCurrentView, onExploreClick, onHowItWorksClick }) => {
  const [activeStep, setActiveStep] = useState(0);

  // Cycle through the animated energy flow: Solar -> Energy -> Irrigation -> Crop -> Harvest
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % 5);
    }, 1800);
    return () => clearInterval(timer);
  }, []);

  const flowNodes = [
    { label: 'Solar', icon: Sun, color: 'text-amber-400', bg: 'bg-amber-400/10', border: 'border-amber-400/30' },
    { label: 'Energy', icon: Zap, color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/30' },
    { label: 'Irrigation', icon: Droplets, color: 'text-cyan-400', bg: 'bg-cyan-400/10', border: 'border-cyan-400/30' },
    { label: 'Crop', icon: Sprout, color: 'text-emerald-400', bg: 'bg-emerald-400/10', border: 'border-emerald-400/30' },
    { label: 'Harvest', icon: Package, color: 'text-lime-400', bg: 'bg-lime-400/10', border: 'border-lime-400/30' }
  ];

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden">
      {/* Background Cinematic Image with Gradient Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/hero-farm.jpg"
          alt="AGRIOS Autonomous Smart Farm"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-10000 ease-out"
        />
        {/* Deep atmospheric overlays matching our brand identity */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#060F09] via-[#060F09]/80 to-[#060F09]/55" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#060F09] via-[#060F09]/75 to-transparent" />
        <div className="absolute inset-0 bg-radial-gradient-hero opacity-60" />
      </div>

      {/* Digital Grid Overlay representing connection between physical farm and AI */}
      <div className="absolute inset-0 z-0 bg-tech-grid opacity-35 pointer-events-none" />

      {/* Atmospheric Sunrise Lighting Accent */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-b from-amber-500/15 via-emerald-500/10 to-transparent blur-3xl pointer-events-none rounded-full" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Vision & Action */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-6 text-left"
          >
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-emerald-950/60 border border-emerald-500/30 backdrop-blur-md">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lime-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-lime-400" />
              </span>
              <span className="text-xs font-mono tracking-wide text-emerald-300 font-medium uppercase">
                AI Autonomous Agronomic Intelligence
              </span>
              <span className="text-[10px] text-lime-300/80 font-mono bg-lime-950/50 px-1.5 py-0.5 rounded border border-lime-500/30">
                v2.4 Live
              </span>
            </div>

            {/* Hero Headline */}
            <h1 className="font-display text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.08]">
              Make Every Drop Work.{' '}
              <span className="block mt-1 text-gradient-emerald">
                Make Every Crop Count.
              </span>
            </h1>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg lg:text-xl text-gray-300 max-w-2xl font-light leading-relaxed">
              AGRIOS turns your farm into an intelligent ecosystem—optimizing{' '}
              <span className="text-white font-medium">water, energy, crop health</span> and{' '}
              <span className="text-white font-medium">productivity</span> with continuous AI-powered decisions.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExploreClick}
                className="group relative px-7 py-3.5 rounded-xl font-bold text-sm text-gray-950 bg-gradient-to-r from-lime-400 via-emerald-400 to-lime-300 shadow-xl shadow-emerald-500/20 hover:shadow-lime-400/40 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2.5"
              >
                <span>Explore AGRIOS</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onHowItWorksClick}
                className="px-6 py-3.5 rounded-xl font-semibold text-sm text-white bg-[#0B1A12]/80 hover:bg-emerald-950/80 border border-emerald-500/25 hover:border-emerald-500/50 backdrop-blur-md transition-all flex items-center gap-2.5 hover:text-lime-300"
              >
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Play className="w-3 h-3 fill-current ml-0.5" />
                </div>
                <span>See How It Works</span>
              </button>
            </div>

            {/* Trust Indicator */}
            <div className="pt-6 border-t border-emerald-500/15 flex items-center gap-3 text-xs font-mono tracking-wider text-emerald-400/80">
              <ShieldCheck className="w-4 h-4 text-lime-400 shrink-0" />
              <div className="flex flex-wrap items-center gap-2">
                <span>AI</span>
                <span className="text-emerald-500/40">•</span>
                <span>IoT</span>
                <span className="text-emerald-500/40">•</span>
                <span>Precision Agriculture</span>
                <span className="text-emerald-500/40">•</span>
                <span className="text-lime-300">Climate Resilience</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Floating Interactive “AI Farm Intelligence” Panel */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative"
          >
            {/* Glowing Backdrop behind panel */}
            <div className="absolute -inset-1.5 bg-gradient-to-r from-emerald-500/20 to-lime-500/20 rounded-3xl blur-xl opacity-70 group-hover:opacity-100 transition duration-1000" />

            <div className="relative rounded-2xl bg-[#09170E]/80 backdrop-blur-2xl border border-emerald-500/30 p-6 sm:p-7 shadow-2xl shadow-black/60 space-y-6">
              
              {/* Header Status Bar */}
              <div className="flex items-center justify-between pb-4 border-b border-emerald-500/15">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-lime-400">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-mono uppercase tracking-wider text-gray-400">
                      AI Farm Intelligence
                    </h3>
                    <p className="text-sm font-bold text-white flex items-center gap-2">
                      FARM STATUS
                      <span className="inline-flex items-center gap-1.5 text-xs text-lime-400 font-semibold bg-lime-950/60 px-2 py-0.5 rounded-full border border-lime-500/30">
                        <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-ping" />
                        Optimal
                      </span>
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-mono text-gray-400">TELEMETRY</div>
                  <div className="text-xs font-mono text-emerald-400 flex items-center gap-1 justify-end">
                    <Activity className="w-3 h-3 animate-pulse" />
                    LIVE SYNC
                  </div>
                </div>
              </div>

              {/* Live Metric Progress Bars */}
              <div className="space-y-4">
                {/* Water Efficiency */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="text-gray-300 font-medium flex items-center gap-1.5">
                      <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                      Water Efficiency
                    </span>
                    <span className="font-mono font-bold text-cyan-300 text-sm">87%</span>
                  </div>
                  <div className="w-full h-2 bg-[#05140C] rounded-full overflow-hidden border border-emerald-500/15">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 rounded-full transition-all duration-1000 shadow-sm shadow-cyan-400/50"
                      style={{ width: '87%' }}
                    />
                  </div>
                </div>

                {/* Solar Utilization */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="text-gray-300 font-medium flex items-center gap-1.5">
                      <Sun className="w-3.5 h-3.5 text-amber-400" />
                      Solar Utilization
                    </span>
                    <span className="font-mono font-bold text-amber-300 text-sm">92%</span>
                  </div>
                  <div className="w-full h-2 bg-[#05140C] rounded-full overflow-hidden border border-emerald-500/15">
                    <div
                      className="h-full bg-gradient-to-r from-lime-500 to-amber-400 rounded-full transition-all duration-1000 shadow-sm shadow-amber-400/50"
                      style={{ width: '92%' }}
                    />
                  </div>
                </div>

                {/* Crop Health */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="text-gray-300 font-medium flex items-center gap-1.5">
                      <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                      Crop Health
                    </span>
                    <span className="font-mono font-bold text-emerald-300 text-sm">94%</span>
                  </div>
                  <div className="w-full h-2 bg-[#05140C] rounded-full overflow-hidden border border-emerald-500/15">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-600 to-lime-400 rounded-full transition-all duration-1000 shadow-sm shadow-lime-400/50"
                      style={{ width: '94%' }}
                    />
                  </div>
                </div>
              </div>

              {/* Resource Optimization Highlight Banner */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/70 via-emerald-900/40 to-lime-950/60 border border-emerald-500/30 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wide">
                    Resource Optimization
                  </span>
                  <div className="text-xs text-gray-200 font-medium mt-0.5">
                    Closed-loop autonomous scheduling
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-display font-extrabold text-lime-400 flex items-center gap-1">
                    <TrendingUp className="w-5 h-5 text-lime-400" />
                    +31%
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400/80">yield & water gain</span>
                </div>
              </div>

              {/* Animated Particle Pipeline: Solar -> Energy -> Irrigation -> Crop -> Harvest */}
              <div className="pt-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-gray-400 mb-2.5">
                  <span className="flex items-center gap-1 text-emerald-300 font-semibold">
                    <Sparkles className="w-3 h-3 text-lime-400" />
                    DYNAMIC FLOW PIPELINE
                  </span>
                  <span className="text-[10px] text-lime-400/80 font-mono">
                    Node {activeStep + 1} of 5
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-1.5 relative">
                  {flowNodes.map((node, idx) => {
                    const IconComponent = node.icon;
                    const isActive = activeStep === idx;
                    const isPassed = activeStep > idx;

                    return (
                      <div
                        key={node.label}
                        className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-300 border ${
                          isActive
                            ? `${node.bg} ${node.border} ring-2 ring-lime-400/50 scale-105 shadow-lg`
                            : isPassed
                            ? 'bg-emerald-950/30 border-emerald-500/20 opacity-90'
                            : 'bg-[#08150D]/60 border-white/5 opacity-50'
                        }`}
                      >
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center mb-1 transition-transform ${
                            isActive ? 'scale-110' : ''
                          }`}
                        >
                          <IconComponent className={`w-4 h-4 ${node.color}`} />
                        </div>
                        <span className="text-[10px] font-medium text-gray-300 truncate">
                          {node.label}
                        </span>

                        {/* Animated flowing dot indicator */}
                        {isActive && (
                          <div className="w-1.5 h-1.5 rounded-full bg-lime-400 mt-1 animate-pulse" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
