import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Droplet, Zap, TrendingDown, Cpu, AlertCircle, Award } from 'lucide-react';

export const WhyAgrios: React.FC = () => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const [counts, setCounts] = useState({ water: 0, energy: 0, postHarvest: 0, layer: 0 });

  useEffect(() => {
    // Smooth counter animation
    const duration = 1600;
    const steps = 40;
    const intervalTime = duration / steps;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      setCounts({
        water: Math.min(30, Math.round(30 * progress)),
        energy: Math.min(25, Math.round(25 * progress)),
        postHarvest: Math.min(20, Math.round(20 * progress)),
        layer: 1
      });

      if (step >= steps) {
        clearInterval(timer);
        setHasAnimated(true);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, []);

  const stats = [
    {
      value: `${counts.water}%`,
      label: 'Potential Water Optimization',
      subtext: 'Deficit-aware closed-loop drip scheduling',
      icon: Droplet,
      color: 'text-cyan-400',
      border: 'border-cyan-500/30',
      glow: 'shadow-cyan-500/10'
    },
    {
      value: `${counts.energy}%`,
      label: 'Potential Energy Reduction',
      subtext: 'Synchronization with peak solar curves',
      icon: Zap,
      color: 'text-amber-400',
      border: 'border-amber-500/30',
      glow: 'shadow-amber-500/10'
    },
    {
      value: `${counts.postHarvest}%`,
      label: 'Reduction in Post-Harvest Losses',
      subtext: 'Moisture cut-off optimization for shelf life',
      icon: TrendingDown,
      color: 'text-lime-400',
      border: 'border-lime-500/30',
      glow: 'shadow-lime-500/10'
    },
    {
      value: `${counts.layer}`,
      label: 'Unified Intelligence Layer',
      subtext: 'Bridging soil, telemetry, and harvest markets',
      icon: Cpu,
      color: 'text-emerald-400',
      border: 'border-emerald-500/30',
      glow: 'shadow-emerald-500/10'
    }
  ];

  return (
    <section id="why-agrios" className="relative py-28 bg-[#040905] overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-emerald-950/20 rounded-full blur-[150px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Award className="w-3.5 h-3.5" />
            <span>Target Performance Benchmarks</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Why <span className="text-gradient-emerald">AGRIOS?</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            Designed from ground up to solve agriculture's twin crises: groundwater depletion and unpredictable climate volatility.
          </p>
        </div>

        {/* 4 Large Counter Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className={`p-7 rounded-3xl bg-[#08150D]/85 border ${stat.border} shadow-2xl ${stat.glow} backdrop-blur-xl relative overflow-hidden group hover:border-lime-400/50 transition-all`}
              >
                {/* Top ambient card light */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl group-hover:bg-emerald-500/10 transition-colors pointer-events-none" />

                <div className="flex items-center justify-between mb-6">
                  <div className="p-3 rounded-2xl bg-black/40 border border-white/10 group-hover:scale-110 transition-transform">
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                    KPI 0{idx + 1}
                  </span>
                </div>

                <div className="font-display text-5xl sm:text-6xl font-black text-white tracking-tight mb-2">
                  {stat.value}
                </div>

                <h3 className="font-display text-lg font-bold text-gray-100 mb-2 leading-snug">
                  {stat.label}
                </h3>

                <p className="text-xs text-gray-400 font-light leading-relaxed">
                  {stat.subtext}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Explicit Required Disclaimer Banner */}
        <div className="max-w-2xl mx-auto">
          <div className="p-4 rounded-2xl bg-[#09170E]/80 border border-emerald-500/20 backdrop-blur-md flex items-center gap-3 text-center sm:text-left justify-center">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
            <p className="text-xs font-mono text-gray-400 leading-normal">
              <strong className="text-gray-200">Prototype / modeled targets</strong> — subject to field validation and local agronomic conditions.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
