import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Sliders, 
  Droplet, 
  Thermometer, 
  Sun, 
  CloudRain, 
  TrendingUp, 
  Zap, 
  Coins, 
  ShieldCheck, 
  Sparkles, 
  RotateCcw,
  CheckCircle2,
  Flame,
  CloudLightning
} from 'lucide-react';
import { SimulatorParams } from '../types';
import { calculateSimulator } from '../data/mockData';

export const WhatIfSimulator: React.FC = () => {
  const [params, setParams] = useState<SimulatorParams>({
    waterAvailability: 68,
    temperature: 31,
    solarAvailability: 85,
    rainProbability: 40
  });

  // Calculate reactive outputs
  const outputs = useMemo(() => calculateSimulator(params), [params]);

  const presetScenarios = [
    {
      name: 'Optimal Balance',
      icon: CheckCircle2,
      params: { waterAvailability: 80, temperature: 27, solarAvailability: 85, rainProbability: 25 },
      color: 'border-emerald-500/40 text-emerald-300'
    },
    {
      name: 'Heatwave Alert',
      icon: Flame,
      params: { waterAvailability: 45, temperature: 41, solarAvailability: 98, rainProbability: 5 },
      color: 'border-amber-500/40 text-amber-300'
    },
    {
      name: 'Monsoon Surge',
      icon: CloudLightning,
      params: { waterAvailability: 95, temperature: 23, solarAvailability: 30, rainProbability: 88 },
      color: 'border-cyan-500/40 text-cyan-300'
    },
    {
      name: 'Groundwater Drought',
      icon: Droplet,
      params: { waterAvailability: 22, temperature: 36, solarAvailability: 90, rainProbability: 10 },
      color: 'border-red-500/40 text-red-300'
    }
  ];

  return (
    <section id="simulator" className="relative py-28 bg-[#050E08] overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[900px] h-[600px] bg-gradient-to-b from-emerald-950/20 via-lime-950/15 to-transparent rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute inset-0 bg-tech-grid opacity-25 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-lime-400 text-xs font-mono uppercase tracking-wider">
            <Sliders className="w-3.5 h-3.5" />
            <span>Digital Twin Simulator</span>
          </div>

          <h2 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Before You Act, <span className="text-gradient-emerald">Simulate the Future.</span>
          </h2>

          <p className="text-base sm:text-lg text-gray-300 font-light">
            Test extreme weather shocks, water canal cuts, and solar radiance curves. Watch the AGRIOS digital twin re-compute water consumption, energy cost, and crop yield in real-time.
          </p>
        </div>

        {/* Quick Scenario Preset Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-10">
          <span className="text-xs font-mono uppercase tracking-wider text-gray-400 mr-2">
            Load Preset Twin:
          </span>
          {presetScenarios.map((sc) => {
            const Icon = sc.icon;
            return (
              <button
                key={sc.name}
                onClick={() => setParams(sc.params)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-mono border bg-[#08170F]/80 hover:bg-[#0B2316] transition-all flex items-center gap-1.5 ${sc.color}`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{sc.name}</span>
              </button>
            );
          })}
          <button
            onClick={() => setParams({ waterAvailability: 68, temperature: 31, solarAvailability: 85, rainProbability: 40 })}
            className="p-1.5 rounded-full bg-[#08170F] border border-white/10 text-gray-400 hover:text-white transition-colors"
            title="Reset to default"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Interactive Digital Twin Workspace (2 Columns) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive Telemetry Controls (6 cols) */}
          <div className="lg:col-span-6 bg-[#08180F]/85 border border-emerald-500/25 rounded-3xl p-6 sm:p-8 backdrop-blur-2xl shadow-2xl space-y-7">
            
            <div className="flex items-center justify-between pb-4 border-b border-emerald-500/15">
              <span className="font-mono text-xs uppercase tracking-widest text-emerald-400 font-bold">
                ENVIRONMENTAL INPUT VECTORS
              </span>
              <span className="text-[10px] font-mono text-lime-400 bg-lime-950/60 px-2 py-0.5 rounded border border-lime-500/30">
                Interactive Microclimate Sliders
              </span>
            </div>

            {/* Slider 1: Water Availability */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-gray-200 flex items-center gap-1.5">
                  <Droplet className="w-4 h-4 text-cyan-400" />
                  Water Availability
                </span>
                <span className="font-mono font-bold text-cyan-300 text-sm">
                  {params.waterAvailability}%
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={params.waterAvailability}
                onChange={(e) => setParams({ ...params, waterAvailability: Number(e.target.value) })}
                className="w-full h-2 bg-[#030B06] rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] font-mono text-gray-400">
                <span>Severe canal deficit (10%)</span>
                <span>Full reservoir buffer (100%)</span>
              </div>
            </div>

            {/* Slider 2: Temperature */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-gray-200 flex items-center gap-1.5">
                  <Thermometer className="w-4 h-4 text-amber-400" />
                  Ambient Temperature
                </span>
                <span className="font-mono font-bold text-amber-300 text-sm">
                  {params.temperature}°C
                </span>
              </div>
              <input
                type="range"
                min="18"
                max="45"
                value={params.temperature}
                onChange={(e) => setParams({ ...params, temperature: Number(e.target.value) })}
                className="w-full h-2 bg-[#030B06] rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] font-mono text-gray-400">
                <span>Mild cool (18°C)</span>
                <span>Extreme heat stress (45°C)</span>
              </div>
            </div>

            {/* Slider 3: Solar Availability */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-gray-200 flex items-center gap-1.5">
                  <Sun className="w-4 h-4 text-yellow-400" />
                  Solar Radiance Availability
                </span>
                <span className="font-mono font-bold text-yellow-300 text-sm">
                  {params.solarAvailability}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={params.solarAvailability}
                onChange={(e) => setParams({ ...params, solarAvailability: Number(e.target.value) })}
                className="w-full h-2 bg-[#030B06] rounded-lg appearance-none cursor-pointer accent-yellow-400"
              />
              <div className="flex justify-between text-[10px] font-mono text-gray-400">
                <span>Overcast / Night (0%)</span>
                <span>Peak solar irradiance (100%)</span>
              </div>
            </div>

            {/* Slider 4: Rain Probability */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-gray-200 flex items-center gap-1.5">
                  <CloudRain className="w-4 h-4 text-blue-400" />
                  Rain Probability (Next 24h)
                </span>
                <span className="font-mono font-bold text-blue-300 text-sm">
                  {params.rainProbability}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={params.rainProbability}
                onChange={(e) => setParams({ ...params, rainProbability: Number(e.target.value) })}
                className="w-full h-2 bg-[#030B06] rounded-lg appearance-none cursor-pointer accent-blue-400"
              />
              <div className="flex justify-between text-[10px] font-mono text-gray-400">
                <span>Clear dry skies (0%)</span>
                <span>Heavy downpour confirmed (100%)</span>
              </div>
            </div>

          </div>

          {/* Right Column: Dynamic Simulation Results & AI Recommendation (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* 4 Dynamic Output Tiles */}
            <div className="grid grid-cols-2 gap-4">
              
              {/* Expected Yield */}
              <div className="p-5 rounded-2xl bg-[#091B10]/90 border border-emerald-500/30 backdrop-blur-xl">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 text-lime-400" />
                    Expected Yield
                  </span>
                </div>
                <div className="text-3xl font-display font-extrabold text-lime-400">
                  {outputs.expectedYield}%
                </div>
                <span className="text-[10px] font-mono text-emerald-400/80">
                  Relative to optimum season
                </span>
              </div>

              {/* Water Consumption */}
              <div className="p-5 rounded-2xl bg-[#091B10]/90 border border-emerald-500/30 backdrop-blur-xl">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Droplet className="w-3.5 h-3.5 text-cyan-400" />
                    Water Consumption
                  </span>
                </div>
                <div className="text-3xl font-display font-extrabold text-cyan-300">
                  {outputs.waterConsumption} L
                </div>
                <span className="text-[10px] font-mono text-cyan-400/80">
                  Preserved: +{outputs.savedWater} L
                </span>
              </div>

              {/* Energy Consumption */}
              <div className="p-5 rounded-2xl bg-[#091B10]/90 border border-emerald-500/30 backdrop-blur-xl">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    Energy Consumption
                  </span>
                </div>
                <div className="text-3xl font-display font-extrabold text-amber-300">
                  {outputs.energyConsumption} kWh
                </div>
                <span className="text-[10px] font-mono text-amber-400/80">
                  Solar offset: {params.solarAvailability > 60 ? 'High' : 'Moderate'}
                </span>
              </div>

              {/* Estimated Cost & Resilience */}
              <div className="p-5 rounded-2xl bg-[#091B10]/90 border border-emerald-500/30 backdrop-blur-xl">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Resilience Score
                  </span>
                </div>
                <div className="text-3xl font-display font-extrabold text-emerald-300">
                  {outputs.resilienceScore}/100
                </div>
                <span className="text-[10px] font-mono text-gray-400">
                  Operating Cost: ₹{outputs.estimatedCost}
                </span>
              </div>

            </div>

            {/* Dynamic AI Recommendation Box */}
            <motion.div
              key={outputs.aiRecommendation}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-6 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-[#0B2717] to-lime-950/70 border-2 border-lime-400/40 shadow-2xl relative overflow-hidden"
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1 rounded-md bg-lime-400/20 text-lime-400">
                  <Sparkles className="w-4 h-4" />
                </div>
                <span className="text-xs font-mono uppercase tracking-widest text-lime-400 font-bold">
                  SIMULATED AI RECOMMENDATION
                </span>
              </div>

              <h4 className="font-display text-xl sm:text-2xl font-bold text-white mb-2 leading-snug">
                “{outputs.aiRecommendation}”
              </h4>

              <p className="text-xs text-gray-300 font-light leading-relaxed">
                By proactively balancing your current parameters, AGRIOS prevents crop dehydration while conserving critical reservoir stock for upcoming climate turbulence.
              </p>
            </motion.div>

          </div>

        </div>

      </div>
    </section>
  );
};
