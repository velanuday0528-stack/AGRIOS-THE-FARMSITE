export type AppView = 'landing' | 'login' | 'signup' | 'onboarding' | 'dashboard';

export interface FarmZone {
  id: string;
  name: string;
  crop: string;
  area: string;
  soilMoisture: number; // percentage
  temperature: number; // Celsius
  cropHealth: number; // percentage
  waterRequirement: number; // Litres
  energyRequirement: number; // kWh
  aiRecommendation: string;
  expectedWaterSaving: string;
  expectedYieldImpact: string;
  status: 'optimal' | 'attention' | 'scheduled';
  coordinates: { x: number; y: number };
}

export interface SimulatorParams {
  waterAvailability: number; // 0 - 100%
  temperature: number; // 18 - 45°C
  solarAvailability: number; // 0 - 100%
  rainProbability: number; // 0 - 100%
}

export interface SimulatorOutputs {
  expectedYield: number; // e.g. 92%
  waterConsumption: number; // Litres
  energyConsumption: number; // kWh
  estimatedCost: number; // Currency or index
  resilienceScore: number; // 0 - 100
  aiRecommendation: string;
  savedWater: number;
}

export interface DropletMilestone {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  waterUsed: string;
  waterSaved: string;
  energyRequired: string;
  expectedCropValue: string;
  efficiencyGain: string;
  detail: string;
}

export interface ChatMessage {
  id: string;
  sender: 'farmer' | 'agrios';
  text: string;
  timestamp: string;
  language?: string;
  audioPlayed?: boolean;
}

export interface OnboardingState {
  step: number;
  farmName: string;
  farmerName: string;
  mobile: string;
  location: string;
  farmSize: string;
  primaryCrop: string;
  crops: string[];
  irrigationType: string;
  energySource: string;
  language: string;
  connectedResources: {
    solar: boolean;
    pump: boolean;
    sensors: boolean;
    waterTank: boolean;
  };
}
