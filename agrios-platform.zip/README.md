# AGRIOS — AI-Powered Smart Farming & Resource Optimization Platform

> **“Make Every Drop Work. Make Every Crop Count.”**  
> *Autonomous agronomic intelligence layer for modern climate-resilient agriculture.*

---

## 🌾 Overview

**AGRIOS** is a world-class climate-tech and agritech web platform combining the visual sophistication of Apple/Tesla design with deep agricultural precision. It bridges soil telemetry, solar power curves, satellite weather forecasting, and market demand into real-time autonomous recommendations.

---

## 🚀 Quick Deployment Guide

You can deploy this project in under 2 minutes:

### Option 1: Deploy to Vercel (Recommended)
1. Push this repository to GitHub or GitLab.
2. Go to [Vercel](https://vercel.com) and click **"Add New Project"**.
3. Import your repository. Vercel will automatically detect **Vite**:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Click **Deploy**.

### Option 2: Deploy to Netlify
1. Drag and drop the `dist/` folder directly to [Netlify Drop](https://app.netlify.com/drop), OR
2. Connect your Git repository:
   - **Build Command**: `npm run build`
   - **Publish Directory**: `dist`
3. Click **Deploy**.

### Option 3: Deploy to GitHub Pages or Any Static Host
The production build is already pre-generated in the `dist/` folder. Simply upload the contents of `dist/` to any web server (Apache, Nginx, AWS S3 + CloudFront, Cloudflare Pages).

---

## 💻 Local Development Setup

To run and modify the project locally:

1. **Prerequisites**: Ensure you have [Node.js](https://nodejs.org/) (v18 or higher) installed.
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Start local development server**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.
4. **Build production bundle**:
   ```bash
   npm run build
   ```

---

## 📁 Project Architecture

```
agrios-platform/
├── public/
│   └── assets/             # Generated cinematic smart farm imagery
│       ├── hero-farm.jpg   # Photorealistic smart field & solar infrastructure
│       └── login-farm.jpg  # Automated greenhouse & hydroponics facility
├── src/
│   ├── components/         # Reusable interactive platform components
│   │   ├── Navbar.tsx             # Glassmorphic sticky navigation
│   │   ├── Hero.tsx               # Full-screen hero with live AI panel
│   │   ├── CoreConcept.tsx        # 5 interconnected resource nodes & AI Engine
│   │   ├── TheFarmThinks.tsx      # Predictive AI 7-day timeline simulation
│   │   ├── ResourceOptimization.tsx # Interactive 4-zone farm map & inspector
│   │   ├── DropletJourney.tsx     # Signature interactive water droplet journey
│   │   ├── WhatIfSimulator.tsx    # Digital twin simulator with climate sliders
│   │   ├── AiDecisionEngine.tsx   # Neural data-to-decision pipeline
│   │   ├── WhyAgrios.tsx          # Key metrics & animated counter targets
│   │   ├── ResilienceScore.tsx    # Circular SVG resilience index gauge
│   │   ├── FarmerExperience.tsx   # Voice-first smartphone demo with audio
│   │   ├── FarmToMarket.tsx       # Production to market value chain
│   │   ├── DashboardPreview.tsx   # SaaS preview console
│   │   ├── FooterCta.tsx          # High-impact closing statement & footer
│   │   └── AiAssistantModal.tsx   # Floating "Ask AGRIOS" AI assistant
│   ├── views/              # Dedicated routing views
│   │   ├── LandingView.tsx        # Complete landing experience
│   │   ├── LoginView.tsx          # Dedicated /login screen
│   │   ├── SignupView.tsx         # "Create Your Farm" registration
│   │   ├── OnboardingView.tsx     # 4-step interactive onboarding
│   │   └── DashboardView.tsx      # Full commercial farm management console
│   ├── types/                     # TypeScript definitions & data models
│   ├── data/                      # Agronomic mock telemetry & speech dialogues
│   ├── App.tsx                    # Root component with view routing
│   ├── index.css                  # Tailwind CSS, custom glassmorphism & grid utilities
│   └── main.tsx                   # React root entry
├── dist/                          # Production build output
├── index.html                     # HTML5 template with Google fonts
├── package.json                   # Dependencies and npm scripts
├── tailwind.config.js             # Curated AGRIOS color palette
├── tsconfig.json                  # TypeScript configuration
└── vite.config.ts                 # Vite bundler configuration
```

---

## 🌿 Brand & Visual System

- **Deep Forest Green** (`#060F09`, `#08180E`)
- **Emerald Green** (`#10B981`)
- **Fresh Lime Accents** (`#84CC16`, `#A3E635`)
- **Warm Agricultural Gold** (`#EAB308`, `#FDE047`)
- **Typography**: Google Fonts *Space Grotesk*, *Plus Jakarta Sans*, and *JetBrains Mono*
